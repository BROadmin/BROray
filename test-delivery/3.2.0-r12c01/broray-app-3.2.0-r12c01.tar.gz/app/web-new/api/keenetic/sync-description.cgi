#!/opt/bin/ash
exec /opt/bin/ash     /opt/broray/web-new/api/keenetic/action-common.sh     sync-description
