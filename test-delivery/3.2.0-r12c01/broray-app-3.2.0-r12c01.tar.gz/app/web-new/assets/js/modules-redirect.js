window.location.replace("/home.html?v=WebUI-3.2.0-r12c01");
