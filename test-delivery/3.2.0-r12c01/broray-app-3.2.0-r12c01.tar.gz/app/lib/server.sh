#!/opt/bin/ash

BRORAY_BASE="${BRORAY_BASE:-${BRORAY_ROOT:-/opt/broray}}"

. "$BRORAY_BASE/lib/util.sh"

BRORAY_SERVERS="$BRORAY_BASE/servers"
BRORAY_ACTIVE_SERVER_FILE="$BRORAY_BASE/config/active-server"

broray_server_validate_id() {
    server_id="$1"

    [ -n "$server_id" ] ||
        broray_die "не указан идентификатор сервера"

    case "$server_id" in
        *[!a-zA-Z0-9._-]*)
            broray_die \
                "идентификатор сервера содержит недопустимые символы"
            ;;
    esac
}

broray_server_path() {
    server_id="$1"

    broray_server_validate_id "$server_id"

    printf '%s/%s.json\n' \
        "$BRORAY_SERVERS" \
        "$server_id"
}

broray_server_exists() {
    server_id="$1"
    server_file="$(broray_server_path "$server_id")"

    [ -f "$server_file" ]
}

broray_server_validate__shadowed_legacy_1_unused() {
    validation_file="$1"

    broray_json_validate "$validation_file"

    broray_server_stream_fields_valid "$validation_file" ||
        broray_die "сервер содержит неподдерживаемые параметры TLS/REALITY/FinalMask"
    jq -e '
        (.schemaVersion == 2) and
        (((.id | type) == "string") and ((.id | length) > 0)) and
        ((.name | type) == "string") and
        (((.protocol | type) == "string") and ((.protocol | length) > 0)) and
        (((.address | type) == "string") and ((.address | length) > 0)) and
        (((.port | type) == "number") and (.port >= 1) and (.port <= 65535)) and
        (
            (
                .protocol == "trojan" and
                (((.password | type) == "string") and ((.password | length) > 0))
            ) or
            (
                .protocol != "trojan" and
                (((.uuid | type) == "string") and ((.uuid | length) > 0))
            )
        ) and
        (((.network | type) == "string") and ((.network | length) > 0)) and
        (((.security | type) == "string") and ((.security | length) > 0)) and
        ((.source | type) == "object") and
        (((.source.type | type) == "string") and ((.source.type | length) > 0))
    ' "$validation_file" >/dev/null 2>&1 ||
        broray_die \
            "сервер имеет неправильную структуру: $server_file"
}

broray_server_set_active() {
    server_id="$1"

    broray_server_exists "$server_id" ||
        broray_die "сервер $server_id не найден"

    printf '%s\n' "$server_id" \
        > "$BRORAY_ACTIVE_SERVER_FILE" ||
        broray_die "не удалось записать активный сервер"
}

broray_server_get_active_id() {
    [ -f "$BRORAY_ACTIVE_SERVER_FILE" ] ||
        broray_die "активный сервер не выбран"

    active_server_id="$(
        cat "$BRORAY_ACTIVE_SERVER_FILE"
    )"

    [ -n "$active_server_id" ] ||
        broray_die "файл активного сервера пуст"

    broray_server_exists "$active_server_id" ||
        broray_die \
            "активный сервер $active_server_id не найден"

    printf '%s\n' "$active_server_id"
}

broray_server_current() {
    active_server_id="$(
        broray_server_get_active_id
    )"

    server_file="$(
        broray_server_path "$active_server_id"
    )"

    broray_server_validate "$server_file"

    jq '{
        schemaVersion,
        id,
        name,
        source,
        uri,
        protocol,
        address,
        port,
        uuid,
        flow,
        network,
        security,
        reality,
        xhttp
    }' "$server_file"
}

broray_server_list() {
    found=0

    if [ -f "$BRORAY_ACTIVE_SERVER_FILE" ]; then
        active_server_id="$(
            cat "$BRORAY_ACTIVE_SERVER_FILE"
        )"
    else
        active_server_id=""
    fi

    for server_file in "$BRORAY_SERVERS"/*.json; do
        [ -f "$server_file" ] || continue

        broray_server_validate "$server_file"

        found=1

        server_id="$(jq -r '.id' "$server_file")"
        server_name="$(
            jq -r '.name // .id' "$server_file"
        )"
        server_address="$(
            jq -r '.address' "$server_file"
        )"
        server_port="$(
            jq -r '.port' "$server_file"
        )"
        server_source="$(
            jq -r '.source.type // "unknown"' \
                "$server_file"
        )"

        marker=" "
        [ "$server_id" = "$active_server_id" ] &&
            marker="*"

        printf '%s %s | %s | %s:%s | %s\n' \
            "$marker" \
            "$server_id" \
            "$server_name" \
            "$server_address" \
            "$server_port" \
            "$server_source"
    done

    [ "$found" -eq 1 ] ||
        echo "Серверы отсутствуют."
}

broray_server_delete() {
    server_id="$1"
    broray_server_validate_id "$server_id"

    broray_server_exists "$server_id" ||
        broray_die "сервер $server_id не найден"

    active_server_id=""
    if [ -f "$BRORAY_ACTIVE_SERVER_FILE" ]; then
        active_server_id="$(cat "$BRORAY_ACTIVE_SERVER_FILE")"
    fi

    [ "$server_id" != "$active_server_id" ] ||
        broray_die "нельзя удалить активный сервер"

    server_file="$(broray_server_path "$server_id")"

    rm -f "$server_file" ||
        broray_die "не удалось удалить сервер $server_id"

    printf 'Сервер удалён: %s\n' "$server_id"
}

broray_server_rename() {
    server_id="$1"
    new_name="$2"

    broray_server_validate_id "$server_id"
    [ -n "$new_name" ] || broray_die "не указано новое имя"

    server_file="$(broray_server_path "$server_id")"
    broray_server_exists "$server_id" ||
        broray_die "сервер $server_id не найден"

    tmp="${server_file}.tmp"

    jq --arg name "$new_name" \
        '.name = $name' \
        "$server_file" > "$tmp" ||
        broray_die "не удалось изменить имя"

    mv "$tmp" "$server_file" ||
        broray_die "не удалось сохранить сервер"

    printf 'Сервер переименован: %s\n' "$new_name"
}

# BROray HY2 validation override
broray_server_validate()
{
    validation_file="$1"

    broray_json_validate "$validation_file"

    broray_server_stream_fields_valid "$validation_file" ||
        broray_die "сервер содержит неподдерживаемые параметры TLS/REALITY/FinalMask"
    jq -e '
        (.schemaVersion == 2) and
        (((.id | type) == "string") and ((.id | length) > 0)) and
        ((.name | type) == "string") and
        (((.protocol | type) == "string") and ((.protocol | length) > 0)) and
        (((.address | type) == "string") and ((.address | length) > 0)) and
        (((.port | type) == "number") and (.port >= 1) and (.port <= 65535)) and
        (
            if .protocol == "trojan" then
                (((.password | type) == "string") and ((.password | length) > 0))
            elif .protocol == "hysteria2" then
                ((.auth | type) == "string") and
                (.network == "hysteria") and
                (.security == "tls") and
                ((.hysteria | type) == "object") and
                (.hysteria.version == 2) and
                (.tls.allowInsecure != true) and
                (
                    (.tls | has("pinnedPeerCertSha256") | not) or
                    (.tls.pinnedPeerCertSha256 | type == "string" and length == 64 and
                        (explode | all(.[]; (. >= 48 and . <= 57) or (. >= 97 and . <= 102))))
                ) and
                ((.tls | type) == "object") and
                (
                    ((.tls.serverName | type) == "string") and ((.tls.serverName | length) > 0)
                )
            elif .protocol == "shadowsocks" then
                (((.method | type) == "string") and ((.method | length) > 0)) and
                (((.password | type) == "string") and ((.password | length) > 0)) and
                (.network == "raw") and
                (.security == "none")
            elif .protocol == "vless" then
                ((.encryption // "none") | (. == "none" or (
        split(".") as $p |
        ($p | length) >= 4 and $p[0] == "mlkem768x25519plus" and
        ($p[1] == "native" or $p[1] == "xorpub" or $p[1] == "random") and
        ($p[2] == "0rtt" or $p[2] == "1rtt") and
        (([range(3;($p|length)) | select(($p[.]|length) >= 20)][0]) as $key |
         $key != null and
         all($p[$key:][]; (length == 43 or length == 1579) and
             all(explode[]; (. >= 48 and . <= 57) or (. >= 65 and . <= 90) or (. >= 97 and . <= 122) or . == 45 or . == 95)) and
         ($p[3:$key] as $padding |
          if ($padding|length) == 0 then true else
            all($padding[]; length < 20 and (split("-") | length == 3 and
              all(.[]; length > 0 and all(explode[]; . >= 48 and . <= 57)))) and
            ($padding | map(split("-") | map(tonumber)) |
              all(.[]; all(.[]; . >= 0 and . <= 2147483647) and .[1] <= .[2]) and
              .[0][0] >= 100 and .[0][1] >= 35 and .[0][2] >= 35 and
              ([to_entries[] | select(.key % 2 == 0) | .value[2]] | add) <= 65553)
          end))))) and
                (.security != "reality" or .network == "raw" or .network == "grpc" or .network == "xhttp") and
                (((.uuid | type) == "string") and ((.uuid | length) > 0)) and
                (
                    (.flow == null) or
                    (
                        (.flow == "xtls-rprx-vision" or .flow == "xtls-rprx-vision-udp443") and
                        (.network == "raw" or (.encryption // "none") != "none") and
                        (.security == "reality" or .security == "tls")
                    )
                )
            else
                (((.uuid | type) == "string") and ((.uuid | length) > 0))
            end
        ) and
        (((.network | type) == "string") and ((.network | length) > 0)) and
        (((.security | type) == "string") and ((.security | length) > 0)) and
        ((.source | type) == "object") and
        (((.source.type | type) == "string") and ((.source.type | length) > 0))
    ' "$validation_file" >/dev/null 2>&1 ||
        broray_die \
            "сервер имеет неправильную структуру: $validation_file"
}
