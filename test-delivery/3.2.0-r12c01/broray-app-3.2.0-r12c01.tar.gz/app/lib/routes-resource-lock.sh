#!/opt/bin/ash
# Conservative compatibility lease for the shared route resource. This does
# not recover a crashed route transaction or replace global job admission.
broray_route_restore_file()
{
    local source target temporary
    source="$1"; target="$2"
    [ -f "$source" ] && [ ! -L "$source" ] && [ ! -L "$target" ] || return 1
    temporary="$(mktemp "$target.restore.XXXXXX")" || return 1
    if ! cp -p "$source" "$temporary" || ! cmp -s "$source" "$temporary" ||
       ! mv -f "$temporary" "$target"; then
        rm -f "$temporary"
        return 1
    fi
}

broray_route_rollback_required()
{
    local marker
    marker="$1/rollback-required.json"
    # Existing unknown evidence is itself a stop condition; never replace it.
    [ ! -e "$marker" ] && [ ! -L "$marker" ] || return 0
    (umask 077; set -C; jq -n --arg work "$2" --arg message "$3" \
      '{schemaVersion:1,kind:"routes-rollback-required",blocksNewMutations:true,work:$work,message:$message}' >"$marker")
}

broray_route_resource_request()
{
    local lock parent guard ash pid rest rc job
    lock="$1"; shift
    job=null
    # Resolve membership before taking the resource guard: the coordinator
    # takes its own guard, and recovery uses the opposite dependency below it.
    # The controller rechecks the actual traced caller before publication.
    if [ -n "${BRORAY_BACKGROUND_OPERATION_ID:-}" ]; then
        . "${BRORAY_ROOT:-/opt/broray}/lib/route-job.sh" || return 1
        job="$(broray_route_worker_check)" || return 1
    fi
    parent="${lock%/*}"
    case "$lock" in /*/operation.lock) ;; *) return 1 ;; esac
    [ ! -L "$parent" ] || return 1
    mkdir -p "$parent" || return 1
    [ "$(readlink -f "$parent")" = "$parent" ] || return 1
    guard="${BRORAY_OPS_GUARD:-${BRORAY_ROOT:-/opt/broray}/bin/broray-ops-guard}"
    ash="${BRORAY_OPS_ASH:-/opt/bin/ash}"
    IFS=' ' read -r pid rest </proc/self/stat || return 1
    rc=0
    BRORAY_ROUTE_RESOURCE_JOB_CONTEXT="$job" "$guard" "$parent/resource.control.guard" "$ash" \
      "${BRORAY_ROOT:-/opt/broray}/lib/routes-resource-control.sh" "$lock" "$pid" "$@" || rc=$?
    case "$rc" in 0) return 0 ;; 2|75) return 2 ;; *) return 1 ;; esac
}

broray_route_resource_acquire()
{
    local response rc
    # Capture the actual caller before command substitution changes /proc/self.
    IFS=' ' read -r BRORAY_ROUTE_RESOURCE_CALLER broray_resource_rest </proc/self/stat || return 1
    export BRORAY_ROUTE_RESOURCE_CALLER
    BRORAY_ROUTE_RESOURCE_TOKEN=''
    rc=0; response="$(broray_route_resource_request "$1" acquire "$2" "${3:-}")" || rc=$?
    unset BRORAY_ROUTE_RESOURCE_CALLER
    [ "$rc" = 0 ] || return "$rc"
    case "$response" in ''|*[!0-9a-f]*) return 1 ;; esac
    [ "${#response}" = 32 ] || return 1
    BRORAY_ROUTE_RESOURCE_TOKEN="$response"
}

broray_route_resource_release()
{
    [ -n "${2:-}" ] || return 0
    broray_route_resource_request "$1" release "$2"
}
