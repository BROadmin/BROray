#!/opt/bin/ash

BRORAY_BASE="${BRORAY_BASE:-${BRORAY_ROOT:-/opt/broray}}"

. "$BRORAY_BASE/lib/util.sh"
. "$BRORAY_BASE/lib/parser-vless.sh"
. "$BRORAY_BASE/lib/server.sh"

BRORAY_SERVERS="$BRORAY_BASE/servers"
BRORAY_TMP="$BRORAY_BASE/tmp"

broray_server_generate_id() {
    source_type="$1"
    source_id="$2"
    source_index="$3"

    case "$source_type" in
        subscription)
            [ -n "$source_id" ] ||
                broray_die \
                    "не указан идентификатор подписки"

            case "$source_id" in
                *[!a-zA-Z0-9._-]*)
                    broray_die \
                        "некорректный идентификатор подписки"
                    ;;
            esac

            case "$source_index" in
                ''|*[!0-9]*)
                    broray_die \
                        "некорректный номер узла подписки"
                    ;;
            esac

            printf 'subscription-%s-%04d\n' \
                "$source_id" \
                "$source_index"
            ;;

        manual)
            timestamp="$(date '+%Y%m%d%H%M%S')"
            attempt=0
            while [ "$attempt" -lt 32 ]; do
                nonce="$(hexdump -n 4 -e '4/1 "%02x"' /dev/urandom 2>/dev/null)"
                case "$nonce" in ????????) ;; *) broray_die "не удалось получить случайный идентификатор сервера" ;; esac
                candidate_id="manual-$timestamp-$nonce"
                if [ ! -e "$BRORAY_SERVERS/$candidate_id.json" ] && [ ! -L "$BRORAY_SERVERS/$candidate_id.json" ]; then
                    printf '%s\n' "$candidate_id"
                    return 0
                fi
                attempt=$((attempt + 1))
            done
            broray_die "не удалось выделить уникальный идентификатор сервера"
            ;;

        *)
            broray_die \
                "неподдерживаемый источник сервера"
            ;;
    esac
}

broray_server_save_parsed() {
    original_uri="$1"
    server_id="$2"
    source_type="$3"
    source_id="${4:-}"
    source_index="${5:-0}"

    broray_server_validate_id "$server_id"
    [ -n "$BRORAY_UUID" ] || broray_die "парсер не вернул UUID"
    [ -n "$BRORAY_ADDRESS" ] || broray_die "парсер не вернул адрес"
    case "$BRORAY_PORT" in ''|*[!0-9]*) broray_die "порт должен быть числом" ;; esac
    [ "$BRORAY_PORT" -ge 1 ] 2>/dev/null && [ "$BRORAY_PORT" -le 65535 ] 2>/dev/null || broray_die "порт должен находиться в диапазоне 1–65535"
    case "$BRORAY_NETWORK" in raw|ws|grpc|httpupgrade|xhttp|kcp) ;; *) broray_die "неподдерживаемый транспорт VLESS: $BRORAY_NETWORK" ;; esac
    case "$BRORAY_SECURITY" in none|tls|reality) ;; *) broray_die "неподдерживаемая защита VLESS: $BRORAY_SECURITY" ;; esac
    case "${BRORAY_FLOW:-}" in ''|xtls-rprx-vision|xtls-rprx-vision-udp443) ;; *) broray_die "неподдерживаемый режим VLESS flow: $BRORAY_FLOW" ;; esac
    broray_vless_encryption_valid "${BRORAY_ENCRYPTION:-none}" || broray_die "неподдерживаемый или некорректный VLESS encryption"
    if [ -n "${BRORAY_FLOW:-}" ] &&
       { { [ "$BRORAY_NETWORK" != raw ] && [ "${BRORAY_ENCRYPTION:-none}" = none ]; } || { [ "$BRORAY_SECURITY" != reality ] && [ "$BRORAY_SECURITY" != tls ]; }; }; then
        broray_die "VLESS Vision требует TLS/REALITY и TCP/RAW либо поддерживаемого VLESS encryption"
    fi
    if [ "$BRORAY_SECURITY" = reality ]; then
        case "$BRORAY_NETWORK" in raw|grpc|xhttp) ;; *) broray_die "VLESS REALITY не поддерживает этот транспорт" ;; esac
        [ -n "$BRORAY_SNI" ] || broray_die "для VLESS REALITY не указан SNI"
        [ -n "$BRORAY_PBK" ] || broray_die "для VLESS REALITY не указан public key"
    fi
    printf '%s' "$BRORAY_EXTRA" | jq -e 'type == "object"' >/dev/null 2>&1 || broray_die "параметр extra содержит неправильный JSON"
    printf '%s' "$BRORAY_ALPN" | jq -e 'type == "array"' >/dev/null 2>&1 || broray_die "VLESS ALPN имеет неправильный формат"

    mkdir -p "$BRORAY_SERVERS" "$BRORAY_TMP"
    server_file="$(broray_server_path "$server_id")" || return 1
    [ ! -e "$server_file" ] && [ ! -L "$server_file" ] || broray_die "сервер с идентификатором $server_id уже существует"
    temporary_file="$BRORAY_TMP/server-import.$$.json"

    jq -n \
        --arg id "$server_id" --arg name "$BRORAY_NAME" --arg uri "$original_uri" \
        --arg address "$BRORAY_ADDRESS" --argjson port "$BRORAY_PORT" --arg uuid "$BRORAY_UUID" \
        --arg encryption "$BRORAY_ENCRYPTION" --arg flow "${BRORAY_FLOW:-}" --arg network "$BRORAY_NETWORK" --arg security "$BRORAY_SECURITY" \
        --arg sourceType "$source_type" --arg sourceId "$source_id" --argjson sourceIndex "$source_index" \
        --arg sni "$BRORAY_SNI" --arg fingerprint "$BRORAY_FP" --argjson allowInsecure "$BRORAY_ALLOW_INSECURE" \
        --argjson alpn "$BRORAY_ALPN" --arg publicKey "$BRORAY_PBK" --arg shortId "$BRORAY_SID" --arg spiderX "$BRORAY_SPX" \
        --arg host "$BRORAY_HOST" --arg path "$BRORAY_PATH" --arg serviceName "$BRORAY_SERVICE_NAME" \
        --arg mode "$BRORAY_MODE" --arg headerType "$BRORAY_HEADER_TYPE" --argjson extra "$BRORAY_EXTRA" '
        {
          schemaVersion:2,id:$id,name:$name,
          source:(if $sourceType=="subscription" then {type:$sourceType,subscriptionId:$sourceId,nodeIndex:$sourceIndex} else {type:$sourceType} end),
          uri:$uri,protocol:"vless",address:$address,port:$port,uuid:$uuid,encryption:$encryption,
          flow:(if $flow=="" then null else $flow end),
          network:$network,security:$security,
          tls:{serverName:$sni,fingerprint:$fingerprint,allowInsecure:$allowInsecure,alpn:$alpn},
          reality:{serverName:$sni,fingerprint:$fingerprint,publicKey:$publicKey,shortId:$shortId,spiderX:$spiderX},
          transport:{host:$host,path:$path,serviceName:$serviceName,mode:$mode,headerType:$headerType,extra:$extra},
          xhttp:{path:$path,mode:$mode,extra:$extra}
        }' > "$temporary_file" || broray_die "не удалось создать файл сервера"
    broray_server_save_stream_extensions "$temporary_file"
    broray_server_validate "$temporary_file"
    mv "$temporary_file" "$server_file" || broray_die "не удалось сохранить сервер"
    chmod 600 "$server_file"
    printf '%s\n' "$server_file"
}

broray_server_import_vless() {
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    [ -n "$original_uri" ] ||
        broray_die "не указана ссылка VLESS"

    case "$original_uri" in
        vless://*)
            ;;
        *)
            broray_die \
                "пока поддерживается импорт только VLESS"
            ;;
    esac

    broray_parse_vless "$original_uri" || return 1

    server_id="$(
        broray_server_generate_id \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_id" ] || return 1

    server_file="$(
        broray_server_save_parsed \
            "$original_uri" \
            "$server_id" \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_file" ] || return 1


    echo "Сервер импортирован:"
    echo "ID: $server_id"
    echo "Название: $BRORAY_NAME"
    echo "UUID клиента: $BRORAY_UUID"
    echo "Адрес: $BRORAY_ADDRESS:$BRORAY_PORT"
    echo "Файл: $server_file"
}

broray_server_detect_protocol() {
    uri="$1"

    case "$uri" in
        vless://*)
            printf '%s\n' "vless"
            ;;
        vmess://*)
            printf '%s\n' "vmess"
            ;;
        trojan://*)
            printf '%s\n' "trojan"
            ;;
        ss://*)
            printf '%s\n' "shadowsocks"
            ;;
        hysteria2://*|hy2://*)
            printf '%s\n' "hysteria2"
            ;;
        tuic://*)
            printf '%s\n' "tuic"
            ;;
        socks://*|socks5://*)
            printf '%s\n' "socks"
            ;;
        http://*|https://*)
            printf '%s\n' "http"
            ;;
        *)
            broray_die \
                "неподдерживаемый формат конфигурации"
            ;;
    esac
}

broray_server_import__shadowed_legacy_1_unused() {
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    [ -n "$original_uri" ] ||
        broray_die "не указана ссылка конфигурации"

    protocol="$(
        broray_server_detect_protocol "$original_uri"
    )"

    case "$protocol" in
        vless)
            broray_server_import_vless \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        vmess)
            broray_server_import_vmess \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        trojan)
            broray_server_import_trojan \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        shadowsocks)
            broray_server_import_shadowsocks \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        hysteria2)
            broray_die \
                "парсер Hysteria2 ещё не реализован"
            ;;
        tuic)
            broray_die \
                "парсер TUIC ещё не реализован"
            ;;
        socks)
            broray_die \
                "парсер SOCKS ещё не реализован"
            ;;
        http)
            broray_die \
                "парсер HTTP-прокси ещё не реализован"
            ;;
        *)
            broray_die \
                "для протокола $protocol отсутствует импортёр"
            ;;
    esac
}

broray_server_save_vmess() {
    original_uri="$1"
    server_id="$2"
    source_type="$3"
    source_id="${4:-}"
    source_index="${5:-0}"

    broray_server_validate_id "$server_id"

    case "$BRORAY_PORT" in
        ''|*[!0-9]*)
            broray_die \
                "порт VMess должен быть числом"
            ;;
    esac

    [ "$BRORAY_PORT" -ge 1 ] 2>/dev/null &&
    [ "$BRORAY_PORT" -le 65535 ] 2>/dev/null ||
        broray_die \
            "порт VMess должен находиться в диапазоне 1–65535"

    case "$BRORAY_NETWORK" in
        raw|ws|grpc|httpupgrade|xhttp|kcp)
            ;;
        *)
            broray_die \
                "неподдерживаемый транспорт VMess: $BRORAY_NETWORK"
            ;;
    esac

    case "$BRORAY_SECURITY" in
        none|tls|reality)
            ;;
        *)
            broray_die \
                "неподдерживаемая защита VMess: $BRORAY_SECURITY"
            ;;
    esac

    if [ "$BRORAY_SECURITY" = "reality" ]; then
        case "$BRORAY_NETWORK" in
            raw|grpc|xhttp)
                ;;
            *)
                broray_die \
                    "REALITY несовместима с транспортом $BRORAY_NETWORK"
                ;;
        esac

        [ -n "$BRORAY_SNI" ] ||
            broray_die \
                "для VMess REALITY не указан SNI"

        [ -n "$BRORAY_PBK" ] ||
            broray_die \
                "для VMess REALITY не указан public key"
    fi

    printf '%s' "$BRORAY_EXTRA" |
        jq -e . >/dev/null 2>&1 ||
        broray_die \
            "VMess extra содержит неправильный JSON"

    printf '%s' "$BRORAY_ALPN" |
        jq -e 'type == "array"' >/dev/null 2>&1 ||
        broray_die \
            "VMess ALPN имеет неправильный формат"

    mkdir -p \
        "$BRORAY_SERVERS" \
        "$BRORAY_TMP"

    server_file="$(
        broray_server_path "$server_id"
    )"

    temporary_file="$BRORAY_TMP/server-import.$$.json"

    jq -n \
        --arg id "$server_id" \
        --arg name "$BRORAY_NAME" \
        --arg uri "$original_uri" \
        --arg address "$BRORAY_ADDRESS" \
        --argjson port "$BRORAY_PORT" \
        --arg uuid "$BRORAY_UUID" \
        --argjson alterId "$BRORAY_ALTER_ID" \
        --arg encryption "$BRORAY_ENCRYPTION" \
        --arg network "$BRORAY_NETWORK" \
        --arg security "$BRORAY_SECURITY" \
        --arg sourceType "$source_type" \
        --arg sourceId "$source_id" \
        --argjson sourceIndex "$source_index" \
        --arg sni "$BRORAY_SNI" \
        --arg fingerprint "$BRORAY_FP" \
        --argjson allowInsecure "$BRORAY_ALLOW_INSECURE" \
        --argjson alpn "$BRORAY_ALPN" \
        --arg publicKey "$BRORAY_PBK" \
        --arg shortId "$BRORAY_SID" \
        --arg spiderX "$BRORAY_SPX" \
        --arg host "$BRORAY_HOST" \
        --arg path "$BRORAY_PATH" \
        --arg serviceName "$BRORAY_SERVICE_NAME" \
        --arg mode "$BRORAY_MODE" \
        --arg headerType "$BRORAY_HEADER_TYPE" \
        --argjson extra "$BRORAY_EXTRA" \
        '{
            schemaVersion: 2,
            id: $id,
            name: $name,
            source: (
                if $sourceType == "subscription"
                then {
                    type: $sourceType,
                    subscriptionId: $sourceId,
                    nodeIndex: $sourceIndex
                }
                else {
                    type: $sourceType
                }
                end
            ),
            uri: $uri,
            protocol: "vmess",
            address: $address,
            port: $port,
            uuid: $uuid,
            alterId: $alterId,
            encryption: $encryption,
            network: $network,
            security: $security,
            tls: {
                serverName: $sni,
                fingerprint: $fingerprint,
                allowInsecure: $allowInsecure,
                alpn: $alpn
            },
            reality: {
                serverName: $sni,
                fingerprint: $fingerprint,
                publicKey: $publicKey,
                shortId: $shortId,
                spiderX: $spiderX
            },
            transport: {
                host: $host,
                path: $path,
                serviceName: $serviceName,
                mode: $mode,
                headerType: $headerType,
                extra: $extra
            }
        }' > "$temporary_file" ||
        broray_die \
            "не удалось создать файл VMess-сервера"

    broray_server_save_stream_extensions "$temporary_file"
    broray_server_validate "$temporary_file"

    mv "$temporary_file" "$server_file" ||
        broray_die \
            "не удалось сохранить VMess-сервер"

    printf '%s\n' "$server_file"
}

broray_server_import_vmess() {
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    . "$BRORAY_BASE/lib/parser-vmess.sh"

    broray_parse_vmess "$original_uri" || return 1

    server_id="$(
        broray_server_generate_id \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_id" ] || return 1

    server_file="$(
        broray_server_save_vmess \
            "$original_uri" \
            "$server_id" \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_file" ] || return 1

    echo "Сервер импортирован:"
    echo "ID: $server_id"
    echo "Название: $BRORAY_NAME"
    echo "Протокол: VMess"
    echo "UUID клиента: $BRORAY_UUID"
    echo "Адрес: $BRORAY_ADDRESS:$BRORAY_PORT"
    echo "Транспорт: $BRORAY_NETWORK"
    echo "Защита: $BRORAY_SECURITY"
    echo "Файл: $server_file"
}

broray_server_save_trojan()
{
    original_uri="$1"
    server_id="$2"
    source_type="$3"
    source_id="${4:-}"
    source_index="${5:-0}"

    broray_server_validate_id "$server_id"

    [ -n "$BRORAY_PASSWORD" ] ||
        broray_die "парсер Trojan не вернул пароль"

    [ -n "$BRORAY_ADDRESS" ] ||
        broray_die "парсер Trojan не вернул адрес"

    case "$BRORAY_PORT" in
        ''|*[!0-9]*)
            broray_die \
                "порт Trojan должен быть числом"
            ;;
    esac

    [ "$BRORAY_PORT" -ge 1 ] 2>/dev/null &&
    [ "$BRORAY_PORT" -le 65535 ] 2>/dev/null ||
        broray_die \
            "порт Trojan должен находиться в диапазоне 1–65535"

    case "$BRORAY_NETWORK" in
        raw|ws|grpc|httpupgrade|xhttp|kcp)
            ;;
        *)
            broray_die \
                "неподдерживаемый транспорт Trojan: $BRORAY_NETWORK"
            ;;
    esac

    case "$BRORAY_SECURITY" in
        tls) ;;
        reality)
            case "$BRORAY_NETWORK" in raw|grpc|xhttp) ;; *) broray_die "Trojan REALITY не поддерживает этот транспорт" ;; esac
            [ -n "$BRORAY_PBK" ] || broray_die "Trojan REALITY требует public key" ;;
        *) broray_die "неподдерживаемая защита Trojan" ;;
    esac

    [ -n "$BRORAY_SNI" ] ||
        broray_die "для Trojan TLS не указан SNI"

    printf '%s' "$BRORAY_ALPN" |
        jq -e 'type == "array"' >/dev/null 2>&1 ||
        broray_die \
            "Trojan ALPN имеет неправильный формат"

    mkdir -p \
        "$BRORAY_SERVERS" \
        "$BRORAY_TMP"

    server_file="$(
        broray_server_path "$server_id"
    )"

    temporary_file="$BRORAY_TMP/server-import.$$.json"

    jq -n \
        --arg id "$server_id" \
        --arg name "$BRORAY_NAME" \
        --arg uri "$original_uri" \
        --arg address "$BRORAY_ADDRESS" \
        --argjson port "$BRORAY_PORT" \
        --arg password "$BRORAY_PASSWORD" \
        --arg network "$BRORAY_NETWORK" \
        --arg security "$BRORAY_SECURITY" \
        --arg sourceType "$source_type" \
        --arg sourceId "$source_id" \
        --argjson sourceIndex "$source_index" \
        --arg sni "$BRORAY_SNI" \
        --arg fingerprint "$BRORAY_FP" \
        --argjson allowInsecure "$BRORAY_ALLOW_INSECURE" \
        --argjson alpn "$BRORAY_ALPN" \
        --arg host "$BRORAY_HOST" \
        --arg path "$BRORAY_PATH" \
        --arg serviceName "$BRORAY_SERVICE_NAME" \
        --arg mode "$BRORAY_MODE" \
        --arg headerType "$BRORAY_HEADER_TYPE" \
        --argjson extra "$BRORAY_EXTRA" \
        '{
            schemaVersion: 2,
            id: $id,
            name: $name,
            source: (
                if $sourceType == "subscription"
                then {
                    type: $sourceType,
                    subscriptionId: $sourceId,
                    nodeIndex: $sourceIndex
                }
                else {
                    type: $sourceType
                }
                end
            ),
            uri: $uri,
            protocol: "trojan",
            address: $address,
            port: $port,
            password: $password,
            network: $network,
            security: $security,
            tls: {
                serverName: $sni,
                fingerprint: $fingerprint,
                allowInsecure: $allowInsecure,
                alpn: $alpn
            },
            transport: {
                host: $host,
                path: $path,
                serviceName: $serviceName,
                mode: $mode,
                headerType: $headerType,
                extra: $extra
            }
        }' > "$temporary_file" ||
        broray_die \
            "не удалось создать файл Trojan-сервера"

    broray_server_save_stream_extensions "$temporary_file"
    broray_server_validate "$temporary_file"

    mv "$temporary_file" "$server_file" ||
        broray_die \
            "не удалось сохранить Trojan-сервер"

    chmod 600 "$server_file"

    printf '%s\n' "$server_file"
}

broray_server_import_trojan()
{
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    . "$BRORAY_BASE/lib/parser-trojan.sh"

    broray_parse_trojan "$original_uri" || return 1

    server_id="$(
        broray_server_generate_id \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_id" ] || return 1

    server_file="$(
        broray_server_save_trojan \
            "$original_uri" \
            "$server_id" \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_file" ] || return 1

    echo "Сервер импортирован:"
    echo "ID: $server_id"
    echo "Название: $BRORAY_NAME"
    echo "Протокол: Trojan"
    echo "Адрес: $BRORAY_ADDRESS:$BRORAY_PORT"
    echo "Транспорт: $BRORAY_NETWORK"
    echo "Защита: $BRORAY_SECURITY"
    echo "Файл: $server_file"
}

broray_server_save_hysteria2()
{
    original_uri="$1"
    server_id="$2"
    source_type="$3"
    source_id="${4:-}"
    source_index="${5:-0}"

    broray_server_validate_id "$server_id"


    [ -n "$BRORAY_ADDRESS" ] ||
        broray_die \
            "парсер Hysteria2 не вернул адрес"

    case "$BRORAY_PORT" in
        ''|*[!0-9]*)
            broray_die \
                "порт Hysteria2 должен быть числом"
            ;;
    esac

    [ "$BRORAY_PORT" -ge 1 ] 2>/dev/null &&
    [ "$BRORAY_PORT" -le 65535 ] 2>/dev/null ||
        broray_die \
            "порт Hysteria2 должен находиться в диапазоне 1–65535"

    [ "$BRORAY_SECURITY" = "tls" ] ||
        broray_die \
            "Hysteria2 поддерживается только с TLS"

    [ -n "$BRORAY_SNI" ] ||
        broray_die \
            "для Hysteria2 не указан SNI"

    printf '%s' "$BRORAY_ALPN" |
        jq -e 'type == "array"' >/dev/null 2>&1 ||
        broray_die \
            "Hysteria2 ALPN имеет неправильный формат"

    printf '%s' "$BRORAY_FINAL_MASK" |
        jq -e 'type == "object"' >/dev/null 2>&1 ||
        broray_die \
            "Hysteria2 final mask имеет неправильный формат"

    mkdir -p \
        "$BRORAY_SERVERS" \
        "$BRORAY_TMP"

    server_file="$(
        broray_server_path "$server_id"
    )"

    temporary_file="$BRORAY_TMP/server-import.$$.json"

    jq -n \
        --arg id "$server_id" \
        --arg name "$BRORAY_NAME" \
        --arg uri "$original_uri" \
        --arg address "$BRORAY_ADDRESS" \
        --argjson port "$BRORAY_PORT" \
        --arg auth "$BRORAY_AUTH" \
        --arg sourceType "$source_type" \
        --arg sourceId "$source_id" \
        --argjson sourceIndex "$source_index" \
        --arg security "$BRORAY_SECURITY" \
        --arg sni "$BRORAY_SNI" \
        --arg fingerprint "$BRORAY_FP" \
        --argjson alpn "$BRORAY_ALPN" \
        --argjson allowInsecure "$BRORAY_ALLOW_INSECURE" \
        --arg pinnedPeerCertSha256 "$BRORAY_PIN_SHA256" \
        --arg ports "${BRORAY_HY2_PORTS:-}" \
        --arg obfs "$BRORAY_OBFS" \
        --arg obfsPassword "$BRORAY_OBFS_PASSWORD" \
        --arg upMbps "$BRORAY_UP_MBPS" \
        --arg downMbps "$BRORAY_DOWN_MBPS" \
        --argjson finalMask "$BRORAY_FINAL_MASK" \
        '{
            schemaVersion: 2,
            id: $id,
            name: $name,
            source: (
                if $sourceType == "subscription"
                then {
                    type: $sourceType,
                    subscriptionId: $sourceId,
                    nodeIndex: $sourceIndex
                }
                else {
                    type: $sourceType
                }
                end
            ),
            uri: $uri,
            protocol: "hysteria2",
            address: $address,
            port: $port,
            auth: $auth,
            network: "hysteria",
            security: $security,
            tls: ({
                serverName: $sni,
                fingerprint: $fingerprint,
                alpn: $alpn,
                allowInsecure: $allowInsecure
            } + (if $pinnedPeerCertSha256 != "" then {pinnedPeerCertSha256:$pinnedPeerCertSha256} else {} end)),
            hysteria: {
                version: 2,
                ports: $ports,
                obfs: $obfs,
                obfsPassword: $obfsPassword,
                upMbps: $upMbps,
                downMbps: $downMbps,
                finalMask: $finalMask
            }
        }' > "$temporary_file" ||
        broray_die \
            "не удалось создать файл Hysteria2-сервера"

    broray_server_save_stream_extensions "$temporary_file"
    broray_server_validate "$temporary_file"

    mv "$temporary_file" "$server_file" ||
        broray_die \
            "не удалось сохранить Hysteria2-сервер"

    chmod 600 "$server_file"

    printf '%s\n' "$server_file"
}

broray_server_import_hysteria2()
{
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    . "$BRORAY_BASE/lib/parser-hysteria2.sh"

    broray_parse_hysteria2 "$original_uri" || return 1

    server_id="$(
        broray_server_generate_id \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_id" ] || return 1

    server_file="$(
        broray_server_save_hysteria2 \
            "$original_uri" \
            "$server_id" \
            "$source_type" \
            "$source_id" \
            "$source_index"
    )"
    [ -n "$server_file" ] || return 1

    echo "Сервер импортирован:"
    echo "ID: $server_id"
    echo "Название: $BRORAY_NAME"
    echo "Протокол: Hysteria2"
    echo "Адрес: $BRORAY_ADDRESS:$BRORAY_PORT"
    echo "SNI: $BRORAY_SNI"
    echo "Маскировка: ${BRORAY_OBFS:-нет}"
    echo "Файл: $server_file"
}

broray_server_save_shadowsocks()
{
    original_uri="$1"
    server_id="$2"
    source_type="$3"
    source_id="${4:-}"
    source_index="${5:-0}"

    broray_server_validate_id "$server_id"
    [ -n "$BRORAY_METHOD" ] ||
        broray_die "парсер Shadowsocks не вернул метод шифрования"
    [ -n "$BRORAY_PASSWORD" ] ||
        broray_die "парсер Shadowsocks не вернул пароль"
    [ -n "$BRORAY_ADDRESS" ] ||
        broray_die "парсер Shadowsocks не вернул адрес"
    case "$BRORAY_PORT" in
        ''|*[!0-9]*) broray_die "порт Shadowsocks должен быть числом" ;;
    esac
    [ "$BRORAY_PORT" -ge 1 ] 2>/dev/null &&
    [ "$BRORAY_PORT" -le 65535 ] 2>/dev/null ||
        broray_die "порт Shadowsocks должен находиться в диапазоне 1–65535"

    mkdir -p "$BRORAY_SERVERS" "$BRORAY_TMP"
    server_file="$(broray_server_path "$server_id")"
    [ ! -e "$server_file" ] && [ ! -L "$server_file" ] ||
        broray_die "сервер с идентификатором $server_id уже существует"
    temporary_file="$BRORAY_TMP/server-import.$$.json"

    jq -n \
        --arg id "$server_id" \
        --arg name "$BRORAY_NAME" \
        --arg uri "$original_uri" \
        --arg address "$BRORAY_ADDRESS" \
        --argjson port "$BRORAY_PORT" \
        --arg method "$BRORAY_METHOD" \
        --arg password "$BRORAY_PASSWORD" \
        --arg sourceType "$source_type" \
        --arg sourceId "$source_id" \
        --argjson sourceIndex "$source_index" '
        {
            schemaVersion: 2,
            id: $id,
            name: $name,
            source: (
                if $sourceType == "subscription"
                then {
                    type: $sourceType,
                    subscriptionId: $sourceId,
                    nodeIndex: $sourceIndex
                }
                else {type: $sourceType}
                end
            ),
            uri: $uri,
            protocol: "shadowsocks",
            address: $address,
            port: $port,
            method: $method,
            password: $password,
            network: "raw",
            security: "none"
        }' > "$temporary_file" ||
        broray_die "не удалось создать файл Shadowsocks-сервера"

    broray_server_validate "$temporary_file"
    mv "$temporary_file" "$server_file" ||
        broray_die "не удалось сохранить Shadowsocks-сервер"
    chmod 600 "$server_file"
    printf '%s\n' "$server_file"
}

broray_server_import_shadowsocks()
{
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    . "$BRORAY_BASE/lib/parser-shadowsocks.sh"
    broray_parse_shadowsocks "$original_uri"

    server_id="$(
        broray_server_generate_id \
            "$source_type" "$source_id" "$source_index"
    )"
    [ -n "$server_id" ] || return 1

    server_file="$(
        broray_server_save_shadowsocks \
            "$original_uri" "$server_id" "$source_type" \
            "$source_id" "$source_index"
    )"
    [ -n "$server_file" ] || return 1

    echo "Сервер импортирован:"
    echo "ID: $server_id"
    echo "Название: $BRORAY_NAME"
    echo "Протокол: Shadowsocks"
    echo "Адрес: $BRORAY_ADDRESS:$BRORAY_PORT"
    echo "Метод: $BRORAY_METHOD"
    echo "Файл: $server_file"
}
# BROray protocol dispatcher override with HY2 and Shadowsocks support
broray_server_import__shadowed_legacy_2_unused()
{
    original_uri="$1"
    source_type="${2:-manual}"
    source_id="${3:-}"
    source_index="${4:-0}"

    [ -n "$original_uri" ] ||
        broray_die \
            "не указана ссылка конфигурации"

    protocol="$(
        broray_server_detect_protocol "$original_uri"
    )"

    case "$protocol" in
        vless)
            broray_server_import_vless \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        vmess)
            broray_server_import_vmess \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        trojan)
            broray_server_import_trojan \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        hysteria2)
            broray_server_import_hysteria2 \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        shadowsocks)
            broray_server_import_shadowsocks \
                "$original_uri" \
                "$source_type" \
                "$source_id" \
                "$source_index"
            ;;
        tuic)
            broray_die \
                "парсер TUIC ещё не реализован"
            ;;
        socks)
            broray_die \
                "парсер SOCKS ещё не реализован"
            ;;
        http)
            broray_die \
                "парсер HTTP-прокси ещё не реализован"
            ;;
        *)
            broray_die \
                "для протокола $protocol отсутствует импортёр"
            ;;
    esac
}

# BROray active subscription server transaction v1

broray_server_import_dispatch()
{
    transaction_uri="$1"
    transaction_source_type="${2:-manual}"
    transaction_source_id="${3:-}"
    transaction_source_index="${4:-0}"

    transaction_protocol="$(
        broray_server_detect_protocol "$transaction_uri"
    )"

    case "$transaction_protocol" in
        vless)
            broray_server_import_vless \
                "$transaction_uri" \
                "$transaction_source_type" \
                "$transaction_source_id" \
                "$transaction_source_index"
            ;;
        vmess)
            broray_server_import_vmess \
                "$transaction_uri" \
                "$transaction_source_type" \
                "$transaction_source_id" \
                "$transaction_source_index"
            ;;
        trojan)
            broray_server_import_trojan \
                "$transaction_uri" \
                "$transaction_source_type" \
                "$transaction_source_id" \
                "$transaction_source_index"
            ;;
        hysteria2)
            broray_server_import_hysteria2 \
                "$transaction_uri" \
                "$transaction_source_type" \
                "$transaction_source_id" \
                "$transaction_source_index"
            ;;
        shadowsocks)
            broray_server_import_shadowsocks \
                "$transaction_uri" \
                "$transaction_source_type" \
                "$transaction_source_id" \
                "$transaction_source_index"
            ;;
        tuic)
            broray_die \
                "парсер TUIC ещё не реализован"
            ;;
        socks)
            broray_die \
                "парсер SOCKS ещё не реализован"
            ;;
        http)
            broray_die \
                "парсер HTTP-прокси ещё не реализован"
            ;;
        *)
            broray_die \
                "для протокола $transaction_protocol отсутствует импортёр"
            ;;
    esac
}

broray_server_import()
{
    transaction_uri="$1"
    transaction_source_type="${2:-manual}"
    transaction_source_id="${3:-}"
    transaction_source_index="${4:-0}"

    [ -n "$transaction_uri" ] ||
        broray_die \
            "не указана ссылка конфигурации"

    transaction_active_id=""

    if [ -f /opt/broray/config/active-server ]; then
        transaction_active_id="$(
            sed -n '1p' /opt/broray/config/active-server
        )"
    fi

    transaction_target_id=""

    if [ "$transaction_source_type" = "subscription" ]; then
        case "$transaction_source_index" in
            ''|*[!0-9]*)
                broray_die \
                    "неправильный индекс узла подписки"
                ;;
        esac

        transaction_target_id="$(
            printf 'subscription-%s-%04d' \
                "$transaction_source_id" \
                "$transaction_source_index"
        )"
    fi

    transaction_old_server=""
    transaction_is_active=false

    if [ -n "$transaction_target_id" ] &&
       [ "$transaction_target_id" = "$transaction_active_id" ]; then

        transaction_is_active=true
        transaction_old_server="/opt/broray/tmp/active-subscription-server.$$.json"

        if [ -f "/opt/broray/servers/$transaction_target_id.json" ]; then
            cp \
                "/opt/broray/servers/$transaction_target_id.json" \
                "$transaction_old_server" ||
                broray_die \
                    "не удалось сохранить прежнюю версию активного сервера"
        fi
    fi

    if ! broray_server_import_dispatch \
        "$transaction_uri" \
        "$transaction_source_type" \
        "$transaction_source_id" \
        "$transaction_source_index"; then

        rm -f "$transaction_old_server"
        broray_die \
            "не удалось импортировать сервер"
    fi

    if [ "$transaction_is_active" = true ]; then
        echo
        echo "Обновлён активный сервер подписки."
        echo "Проверка и применение новой конфигурации..."

        if (
            broray_xray_apply_server "$transaction_target_id"
        ); then
            echo \
                "Новая версия активного сервера успешно применена."
            rm -f "$transaction_old_server"
        else
            echo \
                "Новая версия активного сервера не применена. Выполняется восстановление." \
                >&2

            if [ -f "$transaction_old_server" ]; then
                cp \
                    "$transaction_old_server" \
                    "/opt/broray/servers/$transaction_target_id.json" ||
                    broray_die \
                        "не удалось восстановить прежний сервер"
            fi

            if ! (
                broray_xray_apply_server "$transaction_target_id"
            ); then
                rm -f "$transaction_old_server"

                broray_die \
                    "не удалось восстановить прежнюю рабочую конфигурацию активного сервера"
            fi

            rm -f "$transaction_old_server"

            broray_die \
                "обновление активного сервера отменено: сохранена прежняя рабочая версия"
        fi
    fi
}

broray_server_save_stream_extensions() {
    local target="$1" pins
    pins="$(printf '%s' "${BRORAY_PCS:-}" | tr -d ':' | tr 'A-F' 'a-f')"
    jq --arg header "${BRORAY_RAW_HEADER:-}" --arg ech "${BRORAY_ECH:-}" --arg pcs "$pins" --arg vcn "${BRORAY_VCN:-}" \
       --arg pqv "${BRORAY_PQV:-}" --arg mask "${BRORAY_STREAM_MASK:-}" \
       --arg kcp "${BRORAY_KCP:-}" --arg seed "${BRORAY_KCP_SEED:-}" --arg legacy "${BRORAY_KCP_LEGACY:-false}" \
       --arg sni "${BRORAY_SNI:-}" --arg fp "${BRORAY_FP:-chrome}" --arg pbk "${BRORAY_PBK:-}" --arg sid "${BRORAY_SID:-}" --arg spx "${BRORAY_SPX:-}" '
      (if $header != "" then .transport.header=($header|fromjson) else . end) |
      (if .protocol == "trojan" and .security == "reality" then
         .reality={serverName:$sni,fingerprint:$fp,publicKey:$pbk,shortId:$sid,spiderX:$spx} else . end) |
      (if .network == "kcp" then .transport.kcp=($kcp|fromjson) | .transport.kcpSeed=$seed | .transport.kcpLegacy=($legacy=="true") else . end) |
      (if $ech != "" then .tls.echConfigList=$ech else . end) |
      (if $vcn != "" then .tls.verifyPeerCertByName=$vcn else . end) |
      (if $pcs != "" then
         if (.tls.pinnedPeerCertSha256 // $pcs) != $pcs then error("conflicting certificate pins")
         else .tls.pinnedPeerCertSha256=$pcs end
       else . end) |
      (if $pqv != "" then .reality.mldsa65Verify=$pqv else . end) |
      (if $mask != "" and $mask != "{}" then .transport.finalMask=($mask|fromjson) else . end)
    ' "$target" > "$target.stream" || broray_die "неправильные параметры TLS/REALITY/FinalMask"
    broray_server_stream_fields_valid "$target.stream" || broray_die "неподдерживаемые параметры TLS/REALITY/FinalMask"
    mv "$target.stream" "$target" || broray_die "не удалось сохранить параметры соединения"
}
