#!/opt/bin/ash

# BROray owned route deletion v2 (Keenetic destination + interface identity)

BRORAY_ROUTES_DELETE_ROOT="${BRORAY_ROOT:-/opt/broray}"
BRORAY_ROUTES_DELETE_ROUTES="$BRORAY_ROUTES_DELETE_ROOT/routes"
BRORAY_ROUTES_DELETE_LOCK="$BRORAY_ROUTES_DELETE_ROUTES/locks/operation.lock"
BRORAY_ROUTES_DELETE_ACTIVE_PID=""
BRORAY_ROUTES_DELETE_LOCK_OWNED=false
BRORAY_ROUTES_DELETE_COMMITTED=false
BRORAY_ROUTES_DELETE_ROLLBACK_NEEDED=false
BRORAY_ROUTES_DELETE_DELETED_FILE=""
BRORAY_ROUTES_DELETE_WORK=""
BRORAY_ROUTES_DELETE_ORIGINAL=""
BRORAY_ROUTES_DELETE_BUNDLE_ID=""
BRORAY_ROUTES_DELETE_INTERFACE="${BRORAY_ROUTES_DELETE_INTERFACE:-}"
BRORAY_ROUTES_DELETE_NDMC=""
BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE=false
BRORAY_ROUTES_DELETE_PROGRESS_CURRENT=0
BRORAY_ROUTES_DELETE_PROGRESS_TOTAL=0
BRORAY_ROUTES_DELETE_LAST_ERROR=""
BRORAY_ROUTES_DELETE_COMPLETED_FILE=""
BRORAY_ROUTES_DELETE_TRANSACTION=""
BRORAY_ROUTES_DELETE_PAUSED=false
BRORAY_ROUTES_DELETE_SAVE_NEEDED=false
BRORAY_ROUTES_DELETE_RESUME_BASE=0
BRORAY_ROUTES_DELETE_RESUMED=false
BRORAY_ROUTES_DELETE_PREVIOUS_DELETED=0
BRORAY_ROUTES_DELETE_PREVIOUS_ABSENT=0
BRORAY_ROUTES_DELETE_BATCH_COMMITTED=0

BRORAY_ROOT="${BRORAY_ROOT:-$BRORAY_ROUTES_DELETE_ROOT}"
BRORAY_ROUTES_DELETE_PROGRESS_LIBRARY="${BRORAY_ROUTES_DELETE_PROGRESS_LIBRARY:-$BRORAY_ROOT/lib/routes-operation-progress.sh}"
[ -r "$BRORAY_ROUTES_DELETE_PROGRESS_LIBRARY" ] &&
    . "$BRORAY_ROUTES_DELETE_PROGRESS_LIBRARY"

. "${BRORAY_ROOT:-/opt/broray}/lib/routes-resource-lock.sh" || return 1

broray_routes_delete_progress_begin()
{
    command -v broray_routes_progress_begin >/dev/null 2>&1 || return 0
    broray_routes_progress_begin "$@" || return 1
    BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE=true
}

broray_routes_delete_progress_update()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE" = true ] || return 0
    command -v broray_routes_progress_update >/dev/null 2>&1 || return 0
    broray_routes_progress_update "$@"
}

broray_routes_delete_progress_tick()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE" = true ] || return 0
    command -v broray_routes_progress_tick >/dev/null 2>&1 || return 0
    broray_routes_progress_tick "$@"
}

broray_routes_delete_progress_complete()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE" = true ] || return 0
    command -v broray_routes_progress_complete >/dev/null 2>&1 || return 0
    broray_routes_progress_complete "$@"
}

broray_routes_delete_progress_fail()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE" = true ] || return 0
    command -v broray_routes_progress_fail >/dev/null 2>&1 || return 0
    broray_routes_progress_fail "$@"
}

broray_routes_delete_progress_pause()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_ACTIVE" = true ] || return 0
    command -v broray_routes_progress_pause >/dev/null 2>&1 || return 0
    broray_routes_progress_pause "$@"
}

broray_routes_delete_now()
{
    date '+%Y-%m-%dT%H:%M:%S%z'
}

broray_routes_delete_stamp()
{
    date '+%Y%m%d-%H%M%S'
}

broray_routes_delete_error()
{
    BRORAY_ROUTES_DELETE_LAST_ERROR="$*"
    echo "ОШИБКА: $*" >&2
}

broray_routes_delete_bundle_id_valid()
{
    case "$1" in
        ""|*[!a-z0-9_-]*|????????????????????????????????????????????????????????????????*)
            return 1
            ;;
    esac

    return 0
}

broray_routes_delete_is_pid()
{
    case "$1" in
        ""|*[!0-9]*) return 1 ;;
        *) return 0 ;;
    esac
}

broray_routes_delete_lock_acquire()
{
    broray_route_resource_acquire "$BRORAY_ROUTES_DELETE_LOCK" "delete" "${1:-}" || return $?
    BRORAY_ROUTES_DELETE_LOCK_TOKEN="$BRORAY_ROUTE_RESOURCE_TOKEN"
    BRORAY_ROUTES_DELETE_LOCK_OWNED=true
    return 0
}

broray_routes_delete_lock_release()
{
    broray_route_resource_release "$BRORAY_ROUTES_DELETE_LOCK" "${BRORAY_ROUTES_DELETE_LOCK_TOKEN:-}" || return $?
    BRORAY_ROUTES_DELETE_LOCK_TOKEN=''
    BRORAY_ROUTES_DELETE_LOCK_OWNED=false
    return 0
}

broray_routes_delete_kill_active()
{
    # Commands run synchronously; the native runner drains its own children.
    :
}

broray_routes_delete_ndmc()
{
    command -v broray_routes_static_dispatch_authorize >/dev/null 2>&1 || return 126
    broray_routes_static_dispatch_authorize "$1" || return $?
    . "$BRORAY_ROOT/lib/routes-ndmc.sh" || return 1
    broray_routes_ndmc_capture "$BRORAY_ROUTES_DELETE_NDMC" "$1" "$2" "$3" "${4:-8}"
}

broray_routes_delete_transaction_write()
{
    local file phase deleted_count saved committed message now new

    file="$1"
    phase="$2"
    deleted_count="$3"
    saved="$4"
    committed="$5"
    message="$6"
    now="$(broray_routes_delete_now)"
    new="$file.new.$$"

    jq -n \
        --arg phase "$phase" \
        --arg message "$message" \
        --arg bundleId "$BRORAY_ROUTES_DELETE_BUNDLE_ID" \
        --arg updatedAt "$now" \
        --argjson deletedCount "$deleted_count" \
        --argjson configurationSaved "$saved" \
        --argjson committed "$committed" '
        {
            schemaVersion: 1,
            operation: "delete",
            bundleId: $bundleId,
            phase: $phase,
            deletedCount: $deletedCount,
            configurationSaved: $configurationSaved,
            committed: $committed,
            message: $message,
            updatedAt: $updatedAt
        }
    ' >"$new" || return 1

    mv "$new" "$file"
}

broray_routes_delete_prepare()
{
    local bundle_id registry bundle_registry state plan output_dir now
    local delete_tsv global_new bundle_new state_new plan_new result_new
    local total managed_count external_count physical shared message

    bundle_id="$1"
    registry="$2"
    bundle_registry="$3"
    state="$4"
    plan="$5"
    output_dir="$6"
    now="$7"

    delete_tsv="$output_dir/delete.tsv"
    global_new="$output_dir/routes.json"
    bundle_new="$output_dir/bundle.json"
    state_new="$output_dir/state.json"
    plan_new="$output_dir/export-plan.json"
    result_new="$output_dir/router-delete-result.json"

    mkdir -p "$output_dir" || return 1

    jq -r \
        --slurpfile bundle "$bundle_registry" \
        --arg bundle_id "$bundle_id" \
        --arg target_interface "$managed_interface" '
        $bundle[0].managedRouteKeys as $keys |
        .routes[] |
        select(
            (.key as $key | $keys | index($key)) != null and
            ((.owners // []) | index($bundle_id)) != null and
            ((.owners // []) | length) == 1
        ) |
        [
            .key,
            .network,
            (.prefix | tostring),
            .mask,
            .interface,
            (.metric | tostring)
        ] |
        @tsv
    ' "$registry" >"$delete_tsv" || return 1

    jq -n \
        --slurpfile old "$registry" \
        --slurpfile bundle "$bundle_registry" \
        --arg bundle_id "$bundle_id" \
        --arg now "$now" \
        --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" '
        $old[0] as $o |
        $bundle[0].routeKeys as $bundle_keys |

        [
            ($o.routes // [])[] |
            if (
                (.key as $key | $bundle_keys | index($key)) != null and
                ((.owners // []) | index($bundle_id)) != null
            ) then
                (.owners - [$bundle_id]) as $remaining |
                if ($remaining | length) == 0 then
                    empty
                else
                    .owners = $remaining |
                    .updatedAt = $now
                end
            else
                .
            end
        ] as $routes |

        $o + {
            schemaVersion: 1,
            managedInterface: $target_interface,
            managedMetric: 1200,
            routes: $routes,
            updatedAt: $now
        }
    ' >"$global_new" || return 1

    jq \
        --arg now "$now" \
        --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" '
        .installedVersion = null |
        .routeKeys = [] |
        .managedRouteKeys = [] |
        .externalRouteKeys = [] |
        .targetInterface = $target_interface |
        .managedMetric = 1200 |
        .installedAt = null |
        .removedAt = $now |
        .updatedAt = $now
    ' "$bundle_registry" >"$bundle_new" || return 1

    total="$(jq -r '(.routeKeys // []) | length' "$bundle_registry")"
    managed_count="$(jq -r '(.managedRouteKeys // []) | length' "$bundle_registry")"
    external_count="$(jq -r '(.externalRouteKeys // []) | length' "$bundle_registry")"
    physical="$(wc -l <"$delete_tsv" | tr -d ' ')"
    shared="$((managed_count - physical))"
    message="Маршруты удалены из Keenetic"

    jq \
        --arg now "$now" \
        --arg message "$message" \
        --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" \
        --argjson total "$total" \
        --argjson deleted "$physical" \
        --argjson sharedKept "$shared" \
        --argjson externalKept "$external_count" '
        .status = (
            if .downloadedVersion != null then
                "downloaded"
            else
                "not_checked"
            end
        ) |
        .installedVersion = null |
        .lastDeletedAt = $now |
        .lastVerifiedAt = null |
        .verifyResult = null |
        .deleteResult = {
            result: "removed",
            message: $message,
            total: $total,
            deleted: $deleted,
            sharedKept: $sharedKept,
            externalKept: $externalKept,
            targetInterface: $target_interface,
            managedMetric: 1200,
            configurationSaved: ($deleted > 0),
            completedAt: $now
        } |
        .exportResult = null |
        .preflight = null |
        .lastError = null |
        .updatedAt = $now
    ' "$state" >"$state_new" || return 1

    jq \
        --arg now "$now" \
        --arg message "$message" \
        --argjson deleted "$physical" \
        --argjson sharedKept "$shared" \
        --argjson externalKept "$external_count" '
        .routerApplied = false |
        .configurationSaved = false |
        .removedAt = $now |
        .deleteResult = {
            message: $message,
            deleted: $deleted,
            sharedKept: $sharedKept,
            externalKept: $externalKept,
            managedMetric: 1200
        }
    ' "$plan" >"$plan_new" || return 1

    jq -n \
        --arg bundleId "$bundle_id" \
        --arg now "$now" \
        --arg message "$message" \
        --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" \
        --argjson total "$total" \
        --argjson deleted "$physical" \
        --argjson sharedKept "$shared" \
        --argjson externalKept "$external_count" '
        {
            schemaVersion: 1,
            bundleId: $bundleId,
            targetInterface: $target_interface,
            managedMetric: 1200,
            message: $message,
            summary: {
                total: $total,
                deleted: $deleted,
                sharedKept: $sharedKept,
                externalKept: $externalKept
            },
            routerChanged: ($deleted > 0),
            configurationSaved: ($deleted > 0),
            completedAt: $now
        }
    ' >"$result_new" || return 1

    jq -e --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" '
        (.schemaVersion == 1) and
        (.managedInterface == $target_interface) and
        (.managedMetric == 1200) and
        ((.routes | type) == "array") and
        (all(.routes[];
            (.interface == $target_interface) and
            (.metric == 1200) and
            ((.owners | type) == "array") and
            ((.owners | length) > 0)
        ))
    ' "$global_new" >/dev/null || return 1

    jq -e \
        --arg bundle_id "$bundle_id" '
        (.bundleId == $bundle_id) and
        (.installedVersion == null) and
        ((.routeKeys | length) == 0) and
        ((.managedRouteKeys | length) == 0) and
        ((.externalRouteKeys | length) == 0)
    ' "$bundle_new" >/dev/null || return 1

    jq -e --arg target_interface "$BRORAY_ROUTES_DELETE_INTERFACE" '
        (.installedVersion == null) and
        (.deleteResult.result == "removed") and
        (.deleteResult.targetInterface == $target_interface) and
        (.deleteResult.managedMetric == 1200)
    ' "$state_new" >/dev/null || return 1

    return 0
}

broray_routes_delete_backup_local()
{
    local original registry bundle_registry state plan result

    original="$1"
    registry="$2"
    bundle_registry="$3"
    state="$4"
    plan="$5"
    result="$6"

    mkdir -p "$original" || return 1
    cp -p "$registry" "$original/routes.json" || return 1
    cp -p "$bundle_registry" "$original/bundle.json" || return 1
    cp -p "$state" "$original/state.json" || return 1
    cp -p "$plan" "$original/export-plan.json" || return 1

    if [ -f "$result" ]; then
        cp -p "$result" "$original/router-delete-result.json" || return 1
    else
        : >"$original/router-delete-result.did-not-exist"
    fi
}

broray_routes_delete_install_local()
{
    local prepared registry bundle_registry state plan result

    prepared="$1"
    registry="$2"
    bundle_registry="$3"
    state="$4"
    plan="$5"
    result="$6"

    cp -p "$prepared/routes.json" "$registry.new.$$" || return 1
    cp -p "$prepared/bundle.json" "$bundle_registry.new.$$" || return 1
    cp -p "$prepared/state.json" "$state.new.$$" || return 1
    cp -p "$prepared/export-plan.json" "$plan.new.$$" || return 1
    cp -p "$prepared/router-delete-result.json" "$result.new.$$" || return 1

    mv "$registry.new.$$" "$registry" || return 1
    mv "$bundle_registry.new.$$" "$bundle_registry" || return 1
    mv "$state.new.$$" "$state" || return 1
    mv "$plan.new.$$" "$plan" || return 1
    mv "$result.new.$$" "$result" || return 1
}

broray_routes_delete_restore_local()
{
    local original registry bundle_registry state plan result

    original="$1"
    registry="$2"
    bundle_registry="$3"
    state="$4"
    plan="$5"
    result="$6"

    broray_route_restore_file "$original/routes.json" "$registry" || return 1
    broray_route_restore_file "$original/bundle.json" "$bundle_registry" || return 1
    broray_route_restore_file "$original/state.json" "$state" || return 1
    broray_route_restore_file "$original/export-plan.json" "$plan" || return 1

    if [ -f "$original/router-delete-result.did-not-exist" ]; then
        rm -f "$result" || return 1
    elif [ -f "$original/router-delete-result.json" ]; then
        broray_route_restore_file "$original/router-delete-result.json" "$result" || return 1
    fi
}

broray_routes_delete_rollback_routes()
{
    local tab key network prefix mask interface metric out err command_text
    local failed changed reverse snapshot identity_count attribute_count

    [ -n "$BRORAY_ROUTES_DELETE_DELETED_FILE" ] || return 0
    [ -f "$BRORAY_ROUTES_DELETE_DELETED_FILE" ] || return 0
    broray_routes_static_write_policy_check || return 1

    tab="$(printf '\t')"
    failed=false
    changed=false

    reverse="$BRORAY_ROUTES_DELETE_WORK/rollback.reverse.tsv"
    awk '{line[NR]=$0} END {for (n=NR; n>=1; n--) print line[n]}' \
        "$BRORAY_ROUTES_DELETE_DELETED_FILE" >"$reverse" || return 1
    while IFS="$tab" read -r key network prefix mask interface metric
    do
        [ -n "$network" ] || continue

        out="$BRORAY_ROUTES_DELETE_WORK/rollback-add.out"
        err="$BRORAY_ROUTES_DELETE_WORK/rollback-add.err"
        command_text="ip route $network $mask $interface $metric"

        snapshot="$BRORAY_ROUTES_DELETE_WORK/rollback-before.json"
        rm -f "$snapshot"
        if ! broray_routes_config_fetch "$snapshot" ||
           ! broray_routes_config_serialization_complete "$snapshot"
        then
            failed=true
            continue
        fi
        identity_count="$(broray_routes_config_identity_count \
            "$snapshot" "$network" "$prefix" "$interface" "0.0.0.0")"
        attribute_count="$(broray_routes_config_attribute_count \
            "$snapshot" "$network" "$prefix" "$interface" "0.0.0.0" "$metric")"
        if [ "$identity_count" = 1 ] && [ "$attribute_count" = 1 ]; then
            continue
        fi
        if [ "$identity_count" != 0 ]; then
            failed=true
            continue
        fi

        if ! broray_routes_delete_ndmc "$command_text" "$out" "$err" 8; then
            failed=true
            continue
        fi

        BRORAY_ROUTES_CONFIG_NDMC="$BRORAY_ROUTES_DELETE_NDMC"
        export BRORAY_ROUTES_CONFIG_NDMC
        if broray_routes_config_wait_attribute_state \
               present "$network" "$prefix" "$interface" "0.0.0.0" "$metric" \
               "$BRORAY_ROUTES_DELETE_WORK/rollback-state"
        then
            changed=true
        else
            failed=true
        fi
    done <"$reverse"

    if [ "$changed" = true ]; then
        broray_routes_config_save_converged \
            "$BRORAY_ROUTES_DELETE_WORK/rollback-save" || failed=true
    fi
    [ "$failed" = false ]
}

broray_routes_delete_partial_commit()
{
    local message error_route completed_json output now registry bundle_registry state
    local completed_count deleted_now absent_now total_deleted total_absent

    message="$1"
    error_route="${2:-}"
    completed_json="$BRORAY_ROUTES_DELETE_WORK/completed.json"
    output="$BRORAY_ROUTES_DELETE_WORK/partial"
    now="$(broray_routes_delete_now)"
    registry="$BRORAY_ROUTES_DELETE_ROUTES/installed/routes.json"
    bundle_registry="$BRORAY_ROUTES_DELETE_ROUTES/installed/bundles/$BRORAY_ROUTES_DELETE_BUNDLE_ID.json"
    state="$BRORAY_ROUTES_DELETE_ROUTES/state/$BRORAY_ROUTES_DELETE_BUNDLE_ID.json"

    mkdir -p "$output" || return 1
    jq -Rn '
        [
            inputs | split("\t") | select(length == 7) |
            {
                result: .[0], key: .[1], network: .[2],
                prefix: (.[3] | tonumber), mask: .[4],
                interface: .[5], metric: (.[6] | tonumber)
            }
        ]
    ' <"$BRORAY_ROUTES_DELETE_COMPLETED_FILE" >"$completed_json" || return 1

    completed_count="$(jq -r 'length' "$completed_json")"
    deleted_now="$(jq -r '[.[] | select(.result == "deleted")] | length' "$completed_json")"
    absent_now="$(jq -r '[.[] | select(.result == "absent")] | length' "$completed_json")"
    total_deleted="$((BRORAY_ROUTES_DELETE_PREVIOUS_DELETED + deleted_now))"
    total_absent="$((BRORAY_ROUTES_DELETE_PREVIOUS_ABSENT + absent_now))"

    [ "$completed_count" -eq "$((BRORAY_ROUTES_DELETE_PROGRESS_CURRENT - BRORAY_ROUTES_DELETE_RESUME_BASE))" ] || return 1

    jq -n \
        --slurpfile old "$registry" \
        --slurpfile completed "$completed_json" \
        --arg bundleId "$BRORAY_ROUTES_DELETE_BUNDLE_ID" \
        --arg now "$now" '
        $old[0] as $o |
        ($completed[0] | map(.key) | unique) as $keys |
        [
            ($o.routes // [])[] |
            if (.key as $key | $keys | index($key)) != null then
                .owners = (((.owners // []) - [$bundleId]) | unique) |
                .updatedAt = $now
            else . end |
            select(((.owners // []) | length) > 0)
        ] as $routes |
        $o + {routes: $routes, updatedAt: $now}
    ' >"$output/routes.json" || return 1

    jq -n \
        --slurpfile old "$bundle_registry" \
        --slurpfile completed "$completed_json" \
        --arg now "$now" '
        $old[0] as $o |
        ($completed[0] | map(.key) | unique) as $keys |
        $o + {
            routeKeys: (($o.routeKeys // []) - $keys),
            managedRouteKeys: (($o.managedRouteKeys // []) - $keys),
            externalRouteKeys: (($o.externalRouteKeys // []) - $keys),
            updatedAt: $now
        }
    ' >"$output/bundle.json" || return 1

    jq \
        --arg now "$now" \
        --arg message "$message" \
        --arg errorRoute "$error_route" \
        --argjson current "$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT" \
        --argjson total "$BRORAY_ROUTES_DELETE_PROGRESS_TOTAL" \
        --argjson deleted "$total_deleted" \
        --argjson alreadyAbsent "$total_absent" '
        .status = "installed" |
        .lastVerifiedAt = null |
        .verifyResult = null |
        .preflight = null |
        .resumeOperation = {
            operation: "delete",
            resumable: true,
            current: $current,
            total: $total,
            deleted: $deleted,
            alreadyAbsent: $alreadyAbsent,
            message: $message,
            errorRoute: (if $errorRoute == "" then null else $errorRoute end),
            updatedAt: $now
        } |
        .lastError = (
            if $errorRoute == "" then null
            else {code: "ROUTES_DELETE_PAUSED_AFTER_ERROR", message: $message, route: $errorRoute, resumable: true}
            end
        ) |
        .updatedAt = $now
    ' "$state" >"$output/state.json" || return 1

    jq -e --arg interface "$BRORAY_ROUTES_DELETE_INTERFACE" '
        (.schemaVersion == 1) and
        (.managedInterface == $interface) and
        (.managedMetric == 1200) and
        (([.routes[].key] | length) == ([.routes[].key] | unique | length)) and
        (all(.routes[];
            .interface == $interface and
            .metric == 1200 and
            .createdByBROray == true and
            .managed == true and
            (((.owners // []) | length) > 0)
        ))
    ' "$output/routes.json" >/dev/null 2>&1 || return 1
    jq -e --arg id "$BRORAY_ROUTES_DELETE_BUNDLE_ID" '
        (.bundleId == $id) and
        ((.routeKeys | type) == "array") and
        ((.managedRouteKeys | type) == "array") and
        (.routeKeys == .managedRouteKeys)
    ' "$output/bundle.json" >/dev/null 2>&1 || return 1
    jq -e '.resumeOperation.operation == "delete" and .resumeOperation.resumable == true' \
        "$output/state.json" >/dev/null 2>&1 || return 1

    cp -p "$output/routes.json" "$registry.new.$$" && mv "$registry.new.$$" "$registry" || return 1
    cp -p "$output/bundle.json" "$bundle_registry.new.$$" && mv "$bundle_registry.new.$$" "$bundle_registry" || return 1
    cp -p "$output/state.json" "$state.new.$$" && mv "$state.new.$$" "$state" || return 1
    chmod 644 "$registry" "$bundle_registry" "$state" 2>/dev/null || true
    return 0
}

broray_routes_delete_pause()
{
    local message stopped_by_user error_route exit_code out err details

    message="$1"
    stopped_by_user="${2:-true}"
    error_route="${3:-}"
    case "$stopped_by_user" in true|false) ;; *) stopped_by_user=true ;; esac
    trap - EXIT HUP INT TERM

    if [ "$BRORAY_ROUTES_DELETE_SAVE_NEEDED" = true ]; then
        BRORAY_ROUTES_CONFIG_NDMC="$BRORAY_ROUTES_DELETE_NDMC"
        export BRORAY_ROUTES_CONFIG_NDMC
        if ! broray_routes_config_save_converged \
            "$BRORAY_ROUTES_DELETE_WORK/pause-save-convergence"
        then
            broray_routes_delete_error \
                "Частичное удаление не сошлось между running/startup-config."
            broray_routes_delete_cleanup
            exit 1
        fi
    fi

    broray_routes_delete_partial_commit "$message" "$error_route" || {
        broray_routes_delete_error "Не удалось сохранить состояние удаления для продолжения."
        broray_routes_delete_cleanup
        exit 1
    }

    BRORAY_ROUTES_DELETE_PAUSED=true
    BRORAY_ROUTES_DELETE_ROLLBACK_NEEDED=false
    broray_routes_delete_transaction_write \
        "$BRORAY_ROUTES_DELETE_TRANSACTION" "paused" \
        "$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT" \
        "$BRORAY_ROUTES_DELETE_SAVE_NEEDED" false "$message" || true
    broray_routes_delete_progress_pause "$message" "$stopped_by_user" "$error_route" >/dev/null 2>&1 || true
    broray_routes_delete_lock_release

    printf '%s\n' "$message"
    printf 'Выполнено: %s из %s\n' \
        "$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT" \
        "$BRORAY_ROUTES_DELETE_PROGRESS_TOTAL"
    printf '%s\n' 'Операцию можно продолжить позднее.'

    rm -rf "$BRORAY_ROUTES_DELETE_WORK" 2>/dev/null || true
    BRORAY_ROUTES_DELETE_WORK=""
    if [ "$stopped_by_user" = true ]; then exit 74; else exit 76; fi
}

broray_routes_delete_stop_if_requested()
{
    [ "$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT" -lt "$BRORAY_ROUTES_DELETE_PROGRESS_TOTAL" ] || return 0
    command -v broray_routes_progress_stop_requested >/dev/null 2>&1 || return 0
    if broray_routes_progress_stop_requested "$BRORAY_ROUTES_DELETE_BUNDLE_ID"; then
        broray_routes_delete_pause \
            "Удаление остановлено пользователем. Выполнено $BRORAY_ROUTES_DELETE_PROGRESS_CURRENT из $BRORAY_ROUTES_DELETE_PROGRESS_TOTAL." \
            true ""
    fi
}

broray_routes_delete_verify_batch()
{
    local expected batch_file tag attempts attempt snapshot all_ok tab
    local key network prefix mask interface metric identity_count attribute_count

    expected="$1"
    batch_file="$2"
    tag="$3"
    case "$expected" in present|absent) ;; *) return 1 ;; esac
    [ -s "$batch_file" ] || return 0
    attempts="${BRORAY_ROUTES_CONFIG_CONVERGENCE_ATTEMPTS:-12}"
    case "$attempts" in ''|*[!0-9]*) return 1 ;; esac
    [ "$attempts" -gt 0 ] 2>/dev/null || return 1

    tab="$(printf '\t')"
    attempt=1
    while [ "$attempt" -le "$attempts" ]; do
        snapshot="$BRORAY_ROUTES_DELETE_WORK/$tag.$attempt.json"
        if broray_routes_config_fetch "$snapshot" &&
           broray_routes_config_serialization_complete "$snapshot"
        then
            all_ok=true
            while IFS="$tab" read -r key network prefix mask interface metric; do
                [ -n "$network" ] || continue
                identity_count="$(broray_routes_config_identity_count \
                    "$snapshot" "$network" "$prefix" "$interface" "0.0.0.0")" || {
                    all_ok=false
                    continue
                }
                attribute_count="$(broray_routes_config_attribute_count \
                    "$snapshot" "$network" "$prefix" "$interface" "0.0.0.0" "$metric")" || {
                    all_ok=false
                    continue
                }
                if [ "$expected" = present ]; then
                    [ "$identity_count" = 1 ] && [ "$attribute_count" = 1 ] || all_ok=false
                else
                    [ "$identity_count" = 0 ] || all_ok=false
                fi
            done <"$batch_file"
            if [ "$all_ok" = true ]; then
                rm -f "$snapshot"
                return 0
            fi
        fi
        rm -f "$snapshot"
        attempt=$((attempt + 1))
        [ "$attempt" -gt "$attempts" ] || sleep 1
    done
    return 1
}

broray_routes_delete_commit_verified_batch()
{
    local batch_file tab key network prefix mask interface metric current_route

    batch_file="$1"
    BRORAY_ROUTES_DELETE_BATCH_COMMITTED=0
    [ -s "$batch_file" ] || return 0
    tab="$(printf '\t')"
    while IFS="$tab" read -r key network prefix mask interface metric; do
        [ -n "$network" ] || continue
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            deleted "$key" "$network" "$prefix" "$mask" "$interface" "$metric" \
            >>"$BRORAY_ROUTES_DELETE_COMPLETED_FILE" || return 1
        BRORAY_ROUTES_DELETE_PROGRESS_CURRENT=$((BRORAY_ROUTES_DELETE_PROGRESS_CURRENT + 1))
        BRORAY_ROUTES_DELETE_BATCH_COMMITTED=$((BRORAY_ROUTES_DELETE_BATCH_COMMITTED + 1))
        current_route="$network/$prefix"
        broray_routes_delete_progress_tick \
            "$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT" "$current_route" || return 1
    done <"$batch_file"
    return 0
}

broray_routes_delete_route_failure()
{
    local message route
    message="$1"
    route="$2"
    broray_routes_delete_pause \
        "$message Выполнено $BRORAY_ROUTES_DELETE_PROGRESS_CURRENT из $BRORAY_ROUTES_DELETE_PROGRESS_TOTAL. Можно продолжить после устранения причины." \
        false "$route"
}

broray_routes_delete_cleanup()
{
    local rolled_back progress_error rollback_failed

    trap - EXIT HUP INT TERM
    rolled_back=false
    rollback_failed=false

    broray_routes_delete_kill_active

    if [ "$BRORAY_ROUTES_DELETE_PAUSED" != true ] &&
       [ "$BRORAY_ROUTES_DELETE_ROLLBACK_NEEDED" = true ] &&
       [ "$BRORAY_ROUTES_DELETE_COMMITTED" != true ]
    then
        if broray_routes_delete_rollback_routes; then
            rolled_back=true
        else
            rollback_failed=true
            broray_routes_delete_error \
                "Откат удаления не подтверждён running/startup-config."
        fi

        if [ -n "$BRORAY_ROUTES_DELETE_ORIGINAL" ] &&
           [ -d "$BRORAY_ROUTES_DELETE_ORIGINAL" ]
        then
            broray_routes_delete_restore_local "$BRORAY_ROUTES_DELETE_ORIGINAL" \
                "$BRORAY_ROUTES_DELETE_ROUTES/installed/routes.json" \
                "$BRORAY_ROUTES_DELETE_ROUTES/installed/bundles/$BRORAY_ROUTES_DELETE_BUNDLE_ID.json" \
                "$BRORAY_ROUTES_DELETE_ROUTES/state/$BRORAY_ROUTES_DELETE_BUNDLE_ID.json" \
                "$BRORAY_ROUTES_DELETE_ROUTES/catalog/$BRORAY_ROUTES_DELETE_BUNDLE_ID/export-plan.json" \
                "$BRORAY_ROUTES_DELETE_ROUTES/catalog/$BRORAY_ROUTES_DELETE_BUNDLE_ID/router-delete-result.json" || rollback_failed=true
        else
            rollback_failed=true
        fi
    fi

    if [ "$rollback_failed" = true ]; then
        rolled_back=false
        BRORAY_ROUTES_DELETE_LAST_ERROR='Восстановление не завершено; резервные копии сохранены.'
    fi
    if [ "$BRORAY_ROUTES_DELETE_PAUSED" != true ] &&
       [ "$BRORAY_ROUTES_DELETE_COMMITTED" != true ]; then
        progress_error="${BRORAY_ROUTES_DELETE_LAST_ERROR:-Операция удаления прервана.}"
        if [ "$rolled_back" = true ]; then
            progress_error="$progress_error Изменения операции отменены."
        fi
        broray_routes_delete_progress_fail             "$progress_error" "$rolled_back" >/dev/null 2>&1 || true
    fi

    if [ "$rollback_failed" = true ]; then
        broray_route_rollback_required "$BRORAY_ROUTES_DELETE_ROUTES" "$BRORAY_ROUTES_DELETE_WORK" "$BRORAY_ROUTES_DELETE_LAST_ERROR" || return 1
        broray_routes_delete_lock_release
        return 1
    fi
    broray_routes_delete_lock_release

    if [ -n "$BRORAY_ROUTES_DELETE_WORK" ]; then
        rm -rf "$BRORAY_ROUTES_DELETE_WORK" 2>/dev/null || true
    fi
}

broray_routes_router_delete_run()
{
    local bundle_id config registry bundle_registry state plan result transactions
    local stamp now prepared original transaction delete_tsv deleted_tsv
    local total managed_count external_count physical shared already_absent tab key network prefix mask interface metric
    local actual_config filtered_tsv runtime_absent
    local out err command_text delete_rc deleted_count processed_count save_needed message current_route
    local completed_tsv resume_values resume_base resume_total resumed previous_deleted previous_absent

    bundle_id="$1"

    broray_routes_delete_bundle_id_valid "$bundle_id" || {
        broray_routes_delete_error "Некорректный идентификатор набора."
        return 2
    }

    command -v broray_routes_static_write_policy_check >/dev/null 2>&1 || {
        broray_routes_delete_error "Политика записи статических маршрутов недоступна."
        return 1
    }
    broray_routes_static_write_policy_check || {
        broray_routes_delete_error \
            "Удаление маршрутов не разрешено физически привязанным R14C01-профилем."
        return 1
    }

    [ -r "$BRORAY_ROUTES_DELETE_ROUTES/bundles.json" ] || {
        broray_routes_delete_error "Реестр наборов маршрутов недоступен."
        return 1
    }

    jq -e \
        --arg bundle_id "$bundle_id" '
        (.schemaVersion == 1) and
        ((.bundles | type) == "array") and
        (.bundles | index($bundle_id) != null)
    ' "$BRORAY_ROUTES_DELETE_ROUTES/bundles.json" >/dev/null 2>&1 || {
        broray_routes_delete_error "Набор маршрутов не найден."
        return 1
    }

    BRORAY_ROUTES_DELETE_BUNDLE_ID="$bundle_id"

    config="$BRORAY_ROUTES_DELETE_ROUTES/config.json"
    registry="$BRORAY_ROUTES_DELETE_ROUTES/installed/routes.json"
    bundle_registry="$BRORAY_ROUTES_DELETE_ROUTES/installed/bundles/$bundle_id.json"
    state="$BRORAY_ROUTES_DELETE_ROUTES/state/$bundle_id.json"
    plan="$BRORAY_ROUTES_DELETE_ROUTES/catalog/$bundle_id/export-plan.json"
    result="$BRORAY_ROUTES_DELETE_ROUTES/catalog/$bundle_id/router-delete-result.json"
    transactions="$BRORAY_ROUTES_DELETE_ROUTES/transactions"

    for file in "$config" "$registry" "$bundle_registry" "$state" "$plan"
    do
        [ -r "$file" ] || {
            broray_routes_delete_error "Не найден файл: $file"
            return 1
        }
    done

    if [ -n "${BRORAY_ROUTES_CONFIG_NDMC:-}" ] &&
       [ -x "$BRORAY_ROUTES_CONFIG_NDMC" ]
    then
        BRORAY_ROUTES_DELETE_NDMC="$BRORAY_ROUTES_CONFIG_NDMC"
    else
        BRORAY_ROUTES_DELETE_NDMC="$BRORAY_ROOT/bin/broray-system-ndmc"
    fi
    [ -n "$BRORAY_ROUTES_DELETE_NDMC" ] || {
        broray_routes_delete_error "Команда ndmc недоступна."
        return 1
    }

    managed_interface="$(jq -r '.managedInterface // empty' "$config")"
    case "$managed_interface" in
        Proxy[0-9]*) ;;
        *)
            broray_routes_delete_error "Некорректный управляемый интерфейс Keenetic."
            return 1
            ;;
    esac
    case "${managed_interface#Proxy}" in
        ''|*[!0-9]*)
            broray_routes_delete_error "Некорректный управляемый интерфейс Keenetic."
            return 1
            ;;
    esac
    BRORAY_ROUTES_DELETE_INTERFACE="$managed_interface"
    export BRORAY_ROUTES_DELETE_INTERFACE



    jq -e --arg target_interface "$managed_interface" '
        (.managedInterface == $target_interface) and
        (.managedMetric == 1200) and
        (.ownershipPolicy.deleteOnlyExactManagedMatch == true) and
        (.ownershipPolicy.deleteExternalRoutes == false) and
        (.ownershipPolicy.touchOtherInterfaces == false)
    ' "$config" >/dev/null || {
        broray_routes_delete_error "Политика удаления повреждена."
        return 1
    }

    jq -e \
        --arg bundle_id "$bundle_id" '
        (.bundleId == $bundle_id) and
        (.installedVersion != null) and
        (.managedMetric == 1200) and
        ((.routeKeys | type) == "array") and
        ((.managedRouteKeys | type) == "array")
    ' "$bundle_registry" >/dev/null || {
        broray_routes_delete_error "Набор не установлен или его реестр повреждён."
        return 1
    }

    jq -e \
        --slurpfile bundle "$bundle_registry" \
        --arg bundle_id "$bundle_id" \
        --arg target_interface "$managed_interface" '
        . as $registry |
        $bundle[0].managedRouteKeys as $keys |
        [
            $keys[] as $key |
            any($registry.routes[];
                .key == $key and
                .interface == $target_interface and
                .metric == 1200 and
                .createdByBROray == true and
                .managed == true and
                ((.owners // []) | index($bundle_id)) != null
            )
        ] |
        all
    ' "$registry" >/dev/null || {
        broray_routes_delete_error \
            "Реестр владения не подтверждает все управляемые маршруты."
        return 1
    }

    broray_routes_delete_lock_acquire "$bundle_id" || return 1

    stamp="$(broray_routes_delete_stamp)"
    now="$(broray_routes_delete_now)"
    BRORAY_ROUTES_DELETE_WORK="$BRORAY_ROUTES_DELETE_ROUTES/tmp/delete-$bundle_id-$stamp-$$"
    prepared="$BRORAY_ROUTES_DELETE_WORK/prepared"
    original="$BRORAY_ROUTES_DELETE_WORK/original"
    transaction="$transactions/delete-$bundle_id-$stamp.json"
    BRORAY_ROUTES_DELETE_TRANSACTION="$transaction"
    deleted_tsv="$BRORAY_ROUTES_DELETE_WORK/deleted.tsv"
    completed_tsv="$BRORAY_ROUTES_DELETE_WORK/completed.tsv"

    mkdir -p "$BRORAY_ROUTES_DELETE_WORK" "$transactions" || {
        broray_routes_delete_error "Не удалось создать рабочий каталог."
        return 1
    }

    actual_config="$BRORAY_ROUTES_DELETE_WORK/running-config-before.json"

    command -v broray_routes_config_fetch >/dev/null 2>&1 || {
        broray_routes_delete_error             "Модуль чтения полной конфигурации маршрутов недоступен."
        return 1
    }

    broray_routes_config_fetch "$actual_config" || {
        broray_routes_delete_error             "Не удалось прочитать полный список настроенных маршрутов Keenetic."
        return 1
    }
    broray_routes_config_serialization_complete "$actual_config" || {
        broray_routes_delete_error \
            "running-config содержит неподтверждённую сериализацию статического маршрута."
        return 1
    }

    : >"$deleted_tsv"
    : >"$completed_tsv"
    BRORAY_ROUTES_DELETE_DELETED_FILE="$deleted_tsv"
    BRORAY_ROUTES_DELETE_COMPLETED_FILE="$completed_tsv"
    BRORAY_ROUTES_DELETE_ORIGINAL="$original"

    broray_routes_delete_prepare \
        "$bundle_id" "$registry" "$bundle_registry" "$state" "$plan" \
        "$prepared" "$now" || {
        broray_routes_delete_error "Не удалось подготовить локальное состояние удаления."
        return 1
    }

    # The ownership registry may be stale after manual deletion in Keenetic.
    # Delete only exact BROray objects that still exist in running-config.
    delete_tsv="$prepared/delete.tsv"
    filtered_tsv="$BRORAY_ROUTES_DELETE_WORK/delete.configured.tsv"

    broray_routes_delete_filter_configured \
        "$delete_tsv" \
        "$actual_config" \
        "$filtered_tsv" || {
        broray_routes_delete_error             "Не удалось сопоставить реестр BROray с running-config."
        return 1
    }

    mv -f "$filtered_tsv" "$delete_tsv" || {
        broray_routes_delete_error             "Не удалось подготовить безопасный список удаления."
        return 1
    }

    broray_routes_delete_backup_local \
        "$original" "$registry" "$bundle_registry" "$state" "$plan" "$result" || {
        broray_routes_delete_error "Не удалось создать резервную копию локального состояния."
        return 1
    }

    delete_tsv="$prepared/delete.tsv"
    total="$(jq -r '(.routeKeys // []) | length' "$bundle_registry")"
    managed_count="$(jq -r '(.managedRouteKeys // []) | length' "$bundle_registry")"
    external_count="$(jq -r '(.externalRouteKeys // []) | length' "$bundle_registry")"
    physical="$(wc -l <"$delete_tsv" | tr -d ' ')"
    shared="$(
        jq -r \
            --slurpfile bundle "$bundle_registry" \
            --arg bundle_id "$bundle_id" '
            $bundle[0].managedRouteKeys as $keys |
            [
                .routes[] |
                select(
                    (.key as $key | $keys | index($key)) != null and
                    ((.owners // []) | index($bundle_id)) != null and
                    ((.owners // []) | length) > 1
                )
            ] |
            length
        ' "$registry"
    )"
    already_absent="$((managed_count - shared - physical))"
    [ "$already_absent" -ge 0 ] 2>/dev/null || already_absent=0

    broray_routes_delete_adjust_prepared \
        "$prepared" \
        "$physical" \
        "$shared" \
        "$already_absent" || {
        broray_routes_delete_error             "Не удалось уточнить результат удаления по running-config."
        return 1
    }

    previous_deleted="$(jq -r '.resumeOperation.deleted // 0' "$state" 2>/dev/null || printf 0)"
    previous_absent="$(jq -r '.resumeOperation.alreadyAbsent // 0' "$state" 2>/dev/null || printf 0)"
    case "$previous_deleted" in ''|*[!0-9]*) previous_deleted=0 ;; esac
    case "$previous_absent" in ''|*[!0-9]*) previous_absent=0 ;; esac
    resume_values="$(broray_routes_progress_resume_values "$bundle_id" delete "$physical" 2>/dev/null || printf '0\t%s\tfalse\n' "$physical")"
    resume_base="$(printf '%s' "$resume_values" | cut -f1)"
    resume_total="$(printf '%s' "$resume_values" | cut -f2)"
    resumed="$(printf '%s' "$resume_values" | cut -f3)"
    case "$resume_base" in ''|*[!0-9]*) resume_base=0 ;; esac
    case "$resume_total" in ''|*[!0-9]*) resume_total="$physical" ;; esac
    case "$resumed" in true|false) ;; *) resumed=false ;; esac
    if [ "$resumed" != true ]; then
        previous_deleted=0
        previous_absent=0
    fi

    deleted_count=0
    processed_count="$resume_base"
    save_needed=false
    BRORAY_ROUTES_DELETE_RESUME_BASE="$resume_base"
    BRORAY_ROUTES_DELETE_RESUMED="$resumed"
    BRORAY_ROUTES_DELETE_PREVIOUS_DELETED="$previous_deleted"
    BRORAY_ROUTES_DELETE_PREVIOUS_ABSENT="$previous_absent"
    BRORAY_ROUTES_DELETE_PROGRESS_CURRENT="$resume_base"
    BRORAY_ROUTES_DELETE_PROGRESS_TOTAL="$resume_total"
    broray_routes_delete_progress_begin \
        "$bundle_id" delete "$resume_total" \
        "Подготовка удаления: $resume_base из $resume_total." \
        "$resume_base" "$resumed" || {
        broray_routes_delete_error "Не удалось создать состояние прогресса удаления."
        return 1
    }
    broray_routes_delete_progress_update \
        applying "$resume_base" "$resume_total" "Удаление маршрутов из Keenetic." "" || {
        broray_routes_delete_error "Не удалось обновить состояние прогресса удаления."
        return 1
    }

    broray_routes_delete_transaction_write \
        "$transaction" "checked" 0 false false \
        "Проверка владения завершена." || true

    BRORAY_ROUTES_DELETE_ROLLBACK_NEEDED=true
    tab="$(printf '\t')"
    batch_size="${BRORAY_ROUTES_DELETE_VERIFY_BATCH_SIZE:-16}"
    case "$batch_size" in ''|*[!0-9]*) batch_size=16 ;; esac
    [ "$batch_size" -ge 1 ] 2>/dev/null || batch_size=16
    [ "$batch_size" -le 128 ] 2>/dev/null || batch_size=128
    batch_sequence=0
    batch_count=0
    batch_file="$BRORAY_ROUTES_DELETE_WORK/delete-verify-batch.tsv"
    : >"$batch_file"

    while IFS="$tab" read -r key network prefix mask interface metric
    do
        [ -n "$network" ] || continue

        [ "$interface" = "$managed_interface" ] || {
            broray_routes_delete_error \
                "План удаления вышел за пределы $managed_interface."
            return 1
        }

        [ "$metric" = "1200" ] || {
            broray_routes_delete_error \
                "План удаления содержит чужую метрику."
            return 1
        }

        out="$BRORAY_ROUTES_DELETE_WORK/delete.out"
        err="$BRORAY_ROUTES_DELETE_WORK/delete.err"

        # Identity is destination + interface + gateway.  Metric is retained
        # only so an owned object can be reproduced byte-for-byte on rollback.
        command_text="no ip route $network $mask $managed_interface"
        delete_rc=0

        # Persist the exact reconstructible object before ndmc.  Rollback
        # first inspects running-config, so a delete that never took effect is
        # not re-added and a delete interrupted after applying is recoverable.
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$key" "$network" "$prefix" "$mask" "$interface" "$metric" \
            >>"$deleted_tsv" || {
                broray_routes_delete_error \
                    "Не удалось записать rollback intent для $network/$prefix."
                return 1
            }

        if broray_routes_delete_ndmc "$command_text" "$out" "$err" 8; then
            delete_rc=0
        else
            delete_rc=$?
        fi

        if [ "$delete_rc" -ne 0 ]; then
            details="$(tail -n 20 "$out" 2>/dev/null; tail -n 20 "$err" 2>/dev/null)"
            broray_routes_delete_route_failure \
                "Не удалось удалить $network/$prefix. $details" \
                "$network/$prefix"
        fi

        save_needed=true
        BRORAY_ROUTES_DELETE_SAVE_NEEDED=true
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$key" "$network" "$prefix" "$mask" "$interface" "$metric" \
            >>"$batch_file" || {
                broray_routes_delete_error \
                    "Не удалось записать batch-проверку для $network/$prefix."
                return 1
            }
        batch_count=$((batch_count + 1))
        current_route="$network/$prefix"

        if [ "$batch_count" -ge "$batch_size" ]; then
            batch_sequence=$((batch_sequence + 1))
            BRORAY_ROUTES_CONFIG_NDMC="$BRORAY_ROUTES_DELETE_NDMC"
            export BRORAY_ROUTES_CONFIG_NDMC
            broray_routes_delete_verify_batch \
                absent "$batch_file" "delete-batch-$batch_sequence" ||
                broray_routes_delete_route_failure \
                    "Пакетное удаление маршрутов не сошлось в running-config." \
                    "$network/$prefix"
            broray_routes_delete_commit_verified_batch "$batch_file" || {
                broray_routes_delete_error "Не удалось записать подтверждённый прогресс удаления."
                return 1
            }
            deleted_count=$((deleted_count + BRORAY_ROUTES_DELETE_BATCH_COMMITTED))
            processed_count="$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT"
            : >"$batch_file"
            batch_count=0
            broray_routes_delete_stop_if_requested
            broray_routes_delete_transaction_write \
                "$transaction" "deleting" "$deleted_count" false false \
                "Удаляются управляемые маршруты." || true
        fi
    done <"$delete_tsv"

    if [ "$batch_count" -gt 0 ]; then
        batch_sequence=$((batch_sequence + 1))
        BRORAY_ROUTES_CONFIG_NDMC="$BRORAY_ROUTES_DELETE_NDMC"
        export BRORAY_ROUTES_CONFIG_NDMC
        broray_routes_delete_verify_batch \
            absent "$batch_file" "delete-batch-$batch_sequence" ||
            broray_routes_delete_route_failure \
                "Итоговое пакетное удаление маршрутов не сошлось в running-config." \
                "$current_route"
        broray_routes_delete_commit_verified_batch "$batch_file" || {
            broray_routes_delete_error "Не удалось записать итоговый подтверждённый прогресс удаления."
            return 1
        }
        deleted_count=$((deleted_count + BRORAY_ROUTES_DELETE_BATCH_COMMITTED))
        processed_count="$BRORAY_ROUTES_DELETE_PROGRESS_CURRENT"
        : >"$batch_file"
        batch_count=0
        broray_routes_delete_stop_if_requested
        broray_routes_delete_transaction_write \
            "$transaction" "deleting" "$deleted_count" false false \
            "Удаляются управляемые маршруты." || true
    fi

    runtime_absent="$((physical - deleted_count))"
    [ "$runtime_absent" -ge 0 ] 2>/dev/null || runtime_absent=0

    # Recalculate the persisted result from commands that were actually
    # confirmed. Races with manual deletion remain a successful idempotent
    # removal and are counted as already absent.
    broray_routes_delete_adjust_prepared \
        "$prepared" \
        "$deleted_count" \
        "$shared" \
        "$already_absent" || {
        broray_routes_delete_error             "Не удалось зафиксировать итог безопасного удаления."
        return 1
    }


    broray_routes_delete_progress_update \
        verifying "$processed_count" "$resume_total" \
        "Проверка удаления маршрутов в Keenetic." "" || {
        broray_routes_delete_error "Не удалось записать этап проверки удаления."
        return 1
    }

    # Confirm the real configured state before clearing local ownership.
    # ndmc messages alone are insufficient for hidden routes that coexist on
    # another interface.
    actual_after="$BRORAY_ROUTES_DELETE_WORK/actual-after.json"
    rm -f "${BRORAY_ROUTES_CONFIG_CACHE:-}" 2>/dev/null || true
    broray_routes_config_snapshot "$actual_after" || {
        broray_routes_delete_error "Не удалось повторно прочитать running-config после удаления."
        return 1
    }
    broray_routes_config_serialization_complete "$actual_after" || {
        broray_routes_delete_error \
            "Итоговый running-config содержит неподтверждённую сериализацию."
        return 1
    }

    broray_routes_delete_verify_result \
        "$delete_tsv" \
        "$bundle_registry" \
        "$registry" \
        "$actual_after" || {
        broray_routes_delete_error "Итог удаления не подтверждён полной конфигурацией Keenetic."
        return 1
    }

    # Final result spans all resumed attempts, not only this process.
    broray_routes_delete_adjust_prepared \
        "$prepared" \
        "$((previous_deleted + deleted_count))" \
        "$shared" \
        "$((previous_absent + already_absent))" || {
        broray_routes_delete_error "Не удалось объединить результат продолженной операции удаления."
        return 1
    }
    jq 'del(.resumeOperation)' "$prepared/state.json" >"$prepared/state.json.new.$$" &&
        mv "$prepared/state.json.new.$$" "$prepared/state.json" || return 1

    broray_routes_delete_install_local \
        "$prepared" "$registry" "$bundle_registry" "$state" "$plan" "$result" || {
        broray_routes_delete_error "Не удалось установить локальное состояние удаления."
        return 1
    }

    broray_routes_delete_progress_update \
        saving "$processed_count" "$resume_total" \
        "Сохранение конфигурации Keenetic." "" || {
        broray_routes_delete_error "Не удалось записать этап сохранения конфигурации."
        return 1
    }

    if [ "$save_needed" = true ]; then
        BRORAY_ROUTES_CONFIG_NDMC="$BRORAY_ROUTES_DELETE_NDMC"
        export BRORAY_ROUTES_CONFIG_NDMC
        if ! broray_routes_config_save_converged \
            "$BRORAY_ROUTES_DELETE_WORK/save-convergence"
        then
            broray_routes_delete_error \
                "Конфигурация Keenetic не сошлась между running/startup-config."
            return 1
        fi
    fi

    BRORAY_ROUTES_DELETE_COMMITTED=true
    BRORAY_ROUTES_DELETE_ROLLBACK_NEEDED=false

    message="Маршруты удалены из Keenetic"
    broray_routes_delete_transaction_write \
        "$transaction" "committed" "$deleted_count" \
        "$save_needed" true "$message" || true
    broray_routes_delete_progress_complete \
        "Удаление маршрутов из Keenetic завершено: $resume_total из $resume_total." || true

    broray_routes_delete_lock_release
    rm -rf "$BRORAY_ROUTES_DELETE_WORK" 2>/dev/null || true
    BRORAY_ROUTES_DELETE_WORK=""

    echo "$message"
    echo "Набор: $bundle_id"
    echo "Удалено физических маршрутов BROray: $((previous_deleted + deleted_count))"
    echo "Сохранено общих маршрутов: $shared"
    echo "Уже отсутствовало в Keenetic: $((previous_absent + already_absent))"
    echo "Не затронуто внешних маршрутов: $external_count"
    echo "Интерфейс удаления: $managed_interface"
    echo "Метрика владения BROray: 1200"
    echo "Команда удаления: сеть + маска + $managed_interface"
    echo "Конфигурация сохранена: $save_needed"
    echo "Локально скачанный набор сохранён."
}

# BROray configured-route helpers r10a.
BRORAY_ROUTES_CONFIG_LIBRARY="${BRORAY_ROUTES_CONFIG_LIBRARY:-$BRORAY_ROUTES_DELETE_ROOT/lib/routes-router-config.sh}"

if [ -r "$BRORAY_ROUTES_CONFIG_LIBRARY" ]; then
    . "$BRORAY_ROUTES_CONFIG_LIBRARY"
fi

broray_routes_delete_filter_configured()
{
    local candidates actual output candidate_json

    candidates="$1"
    actual="$2"
    output="$3"
    candidate_json="$output.candidates.$$"

    jq -Rn '
        [
            inputs |
            split("\t") |
            select(length == 6) |
            {
                key: .[0],
                network: .[1],
                prefix: (.[2] | tonumber),
                mask: .[3],
                interface: .[4],
                metric: (.[5] | tonumber)
            }
        ]
    ' <"$candidates" >"$candidate_json" || {
        rm -f "$candidate_json"
        return 1
    }

    jq -e \
        --slurpfile actual "$actual" '
        $actual[0] as $a |
        all(.[];
            . as $candidate |
            ([
                $a.routes[]? |
                select(
                    .serialization.known == true and
                    .network == $candidate.network and
                    .mask == $candidate.mask and
                    .interface == $candidate.interface and
                    .gateway == "0.0.0.0" and
                    .proto == "static"
                )
            ]) as $identity |
            ([
                $identity[] |
                select(
                    .serialization.metricExplicit == true and
                    .metric == $candidate.metric
                )
            ]) as $attributes |
            (($identity | length) == 0) or
            ((($identity | length) == 1) and (($attributes | length) == 1))
        )
    ' "$candidate_json" >/dev/null 2>&1 || {
        rm -f "$candidate_json" "$output"
        return 1
    }

    jq -r \
        --slurpfile actual "$actual" '
        $actual[0] as $a |
        .[] |
        . as $candidate |
        ([
            $a.routes[]? |
            select(
                .serialization.known == true and
                .serialization.metricExplicit == true and
                .network == $candidate.network and
                .mask == $candidate.mask and
                .interface == $candidate.interface and
                ((.gateway // "0.0.0.0") == "0.0.0.0") and
                .metric == $candidate.metric and
                (((.proto // "static") | ascii_downcase) == "static")
            )
        ] | length) as $matches |
        select($matches == 1) |
        [
            .key,
            .network,
            (.prefix | tostring),
            .mask,
            .interface,
            (.metric | tostring)
        ] |
        @tsv
    ' "$candidate_json" >"$output" || {
        rm -f "$candidate_json" "$output"
        return 1
    }

    rm -f "$candidate_json"
    return 0
}

broray_routes_delete_adjust_prepared()
{
    local prepared deleted shared already_absent file new

    prepared="$1"
    deleted="$2"
    shared="$3"
    already_absent="$4"

    file="$prepared/state.json"
    new="$file.new.$$"
    jq \
        --argjson deleted "$deleted" \
        --argjson shared "$shared" \
        --argjson already_absent "$already_absent" '
        .deleteResult.deleted = $deleted |
        .deleteResult.sharedKept = $shared |
        .deleteResult.alreadyAbsent = $already_absent |
        .deleteResult.configurationSaved = ($deleted > 0)
    ' "$file" >"$new" && mv -f "$new" "$file" || return 1

    file="$prepared/export-plan.json"
    new="$file.new.$$"
    jq \
        --argjson deleted "$deleted" \
        --argjson shared "$shared" \
        --argjson already_absent "$already_absent" '
        .deleteResult.deleted = $deleted |
        .deleteResult.sharedKept = $shared |
        .deleteResult.alreadyAbsent = $already_absent
    ' "$file" >"$new" && mv -f "$new" "$file" || return 1

    file="$prepared/router-delete-result.json"
    new="$file.new.$$"
    jq \
        --argjson deleted "$deleted" \
        --argjson shared "$shared" \
        --argjson already_absent "$already_absent" '
        .summary.deleted = $deleted |
        .summary.sharedKept = $shared |
        .summary.alreadyAbsent = $already_absent |
        .routerChanged = ($deleted > 0) |
        .configurationSaved = ($deleted > 0)
    ' "$file" >"$new" && mv -f "$new" "$file" || return 1

    return 0
}


broray_routes_delete_verify_result()
{
    local deleted_tsv bundle_file registry_file actual_file deleted_json

    deleted_tsv="$1"
    bundle_file="$2"
    registry_file="$3"
    actual_file="$4"
    deleted_json="$actual_file.deleted.$$"

    jq -Rn '
        [
            inputs |
            split("\t") |
            select(length == 6) |
            {
                key: .[0],
                network: .[1],
                prefix: (.[2] | tonumber),
                mask: .[3],
                interface: .[4],
                metric: (.[5] | tonumber)
            }
        ]
    ' <"$deleted_tsv" >"$deleted_json" || {
        rm -f "$deleted_json"
        return 1
    }

    jq -e \
        --slurpfile deleted "$deleted_json" \
        --slurpfile bundle "$bundle_file" \
        --slurpfile registry "$registry_file" \
        --slurpfile actual "$actual_file" '
        def identity_match($candidate):
            [
                $actual[0].routes[]? |
                select(
                    .serialization.known == true and
                    .network == $candidate.network and
                    .mask == $candidate.mask and
                    .interface == $candidate.interface and
                    ((.gateway // "0.0.0.0") == "0.0.0.0") and
                    (((.proto // "static") | ascii_downcase) == "static")
                )
            ] | length;
        def attribute_match($candidate):
            [
                $actual[0].routes[]? |
                select(
                    .serialization.known == true and
                    .serialization.metricExplicit == true and
                    .network == $candidate.network and
                    .mask == $candidate.mask and
                    .interface == $candidate.interface and
                    .gateway == "0.0.0.0" and
                    .proto == "static" and
                    .metric == $candidate.metric
                )
            ] | length;

        ($bundle[0].managedRouteKeys // []) as $bundle_keys |
        [
            $registry[0].routes[]? |
            select(
                (.key as $key | $bundle_keys | index($key)) != null and
                ((.owners // []) | length) > 1
            )
        ] as $shared |

        (all($deleted[0][]; identity_match(.) == 0)) and
        (all($shared[]; identity_match(.) == 1 and attribute_match(.) == 1))
    ' "$actual_file" >/dev/null 2>&1
    rc=$?

    rm -f "$deleted_json"
    return "$rc"
}
